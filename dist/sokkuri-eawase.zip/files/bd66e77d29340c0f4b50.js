module.exports={assets:{"_bootstrap": {type:"script",path:"script/_bootstrap.js",global:true,execute: rv => {
'use strict';
const module = rv.module;const exports = module.exports;const require = module.require;const __dirname = rv.dirname;const __filename = rv.filename;
"use strict";

// 通常このファイルを編集する必要はありません。ゲームの処理は main.js に記述してください
const main_1 = require("./main");
module.exports = originalParam => {
  const param = {};
  Object.keys(originalParam).forEach(key => {
    param[key] = originalParam[key];
  });
  // セッションパラメーター
  param.sessionParameter = {};
  // 乱数生成器
  param.random = g.game.random;
  const limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数
  const scene = new g.Scene({
    game: g.game,
    name: "_bootstrap"
  });
  // セッションパラメーターを受け取ってゲームを開始します
  scene.onMessage.add(msg => {
    if (msg.data && msg.data.type === "start" && msg.data.parameters) {
      param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加
      if (msg.data.parameters.randomSeed != null) {
        param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
      }
      g.game.popScene();
      (0, main_1.main)(param);
    }
  });
  scene.onLoad.add(() => {
    let currentTickCount = 0;
    scene.onUpdate.add(function () {
      currentTickCount++;
      // 待ち時間を超えた場合はゲームを開始します
      if (currentTickCount > limitTickToWait) {
        g.game.popScene();
        (0, main_1.main)(param);
      }
    });
  });
  g.game.pushScene(scene);
};
return module.exports;
},
},"main": {type:"script",path:"script/main.js",global:true,execute: rv => {
'use strict';
const module = rv.module;const exports = module.exports;const require = module.require;const __dirname = rv.dirname;const __filename = rv.filename;
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.main = main;
// ======== 調整用パラメータ ========
const PX = 30; // 額縁の中(絵を作る場所)の左上
const PY = 120;
const PW = 640;
const PH = 480;
const RX = 720; // おてほんの左上(半分の大きさで表示)
const RY = 40;
const RS = 0.5;
const TX = 702; // パーツ置き場の左上
const TY = 318;
const TCOLS = 5;
const TCW = 113; // パーツ置き場の1マス(5×2)
const TCH = 196;
const INTRO_SEC = 4;
const REVIEW_SEC = 6.5;
const NEXT_SEC = 2.4; // 次の絵の名前を出す時間
const ROUNDS = [{
  sec: 20,
  min: 5,
  max: 7
}, {
  sec: 25,
  min: 6,
  max: 8
}, {
  sec: 30,
  min: 7,
  max: 9
}];
const FULL_DIST = 160; // これより離れると0点
const PERFECT_DIST = 10; // これより近いとピッタリ
const MM_PER_PX = 0.5;
const SCENES = [{
  name: "春の野原",
  bg: "bg_spring",
  parts: [{
    id: "p_sakura",
    zone: "tree"
  }, {
    id: "p_tulip_r",
    zone: "ground"
  }, {
    id: "p_tulip_y",
    zone: "ground"
  }, {
    id: "p_butterfly",
    zone: "sky"
  }, {
    id: "p_cloud",
    zone: "sky"
  }, {
    id: "p_sun",
    zone: "sky"
  }, {
    id: "p_bird",
    zone: "sky"
  }, {
    id: "p_hiyoko",
    zone: "ground"
  }]
}, {
  name: "夏の野原",
  bg: "bg_summer",
  parts: [{
    id: "p_sun_s",
    zone: "sky"
  }, {
    id: "p_himawari_l",
    zone: "tree"
  }, {
    id: "p_himawari_s",
    zone: "ground"
  }, {
    id: "p_nyudo",
    zone: "sky"
  }, {
    id: "p_suika",
    zone: "ground"
  }, {
    id: "p_ball",
    zone: "ground"
  }, {
    id: "p_parasol",
    zone: "tree"
  }, {
    id: "p_kabuto",
    zone: "ground"
  }]
}, {
  name: "秋の野原",
  bg: "bg_autumn",
  parts: [{
    id: "p_moon",
    zone: "sky"
  }, {
    id: "p_usagi",
    zone: "ground"
  }, {
    id: "p_usagi2",
    zone: "ground"
  }, {
    id: "p_susuki",
    zone: "tree"
  }, {
    id: "p_momiji",
    zone: "tree"
  }, {
    id: "p_dango",
    zone: "ground"
  }, {
    id: "p_kinoko",
    zone: "ground"
  }, {
    id: "p_tonbo",
    zone: "sky"
  }]
}, {
  name: "冬の野原",
  bg: "bg_winter",
  parts: [{
    id: "p_snowman",
    zone: "ground"
  }, {
    id: "p_momi",
    zone: "tree"
  }, {
    id: "p_kamakura",
    zone: "ground"
  }, {
    id: "p_yukiusagi",
    zone: "ground"
  }, {
    id: "p_sori",
    zone: "ground"
  }, {
    id: "p_yukigumo",
    zone: "sky"
  }, {
    id: "p_star",
    zone: "sky"
  }, {
    id: "p_robin",
    zone: "sky"
  }]
}];
const ROOM = {
  name: "おへや",
  bg: "bg_room",
  parts: [{
    id: "p_window",
    zone: "wall"
  }, {
    id: "p_clock",
    zone: "wall"
  }, {
    id: "p_picture",
    zone: "wall"
  }, {
    id: "p_lamp",
    zone: "tall"
  }, {
    id: "p_table",
    zone: "floor"
  }, {
    id: "p_cat",
    zone: "floor"
  }, {
    id: "p_plant",
    zone: "tall"
  }, {
    id: "p_sofa",
    zone: "floor"
  }]
};
const CIRCUS = {
  name: "サーカス",
  bg: "bg_circus",
  parts: [{
    id: "p_clown_a",
    zone: "stagetall"
  }, {
    id: "p_clown_b",
    zone: "stagetall"
  }, {
    id: "p_elephant",
    zone: "stagetall"
  }, {
    id: "p_lion",
    zone: "stage"
  }, {
    id: "p_ring",
    zone: "stagetall"
  }, {
    id: "p_seal",
    zone: "stage"
  }, {
    id: "p_monkey",
    zone: "stagetall"
  }, {
    id: "p_bear",
    zone: "stagetall"
  }, {
    id: "p_trapeze",
    zone: "air"
  }, {
    id: "p_drum",
    zone: "stage"
  }, {
    id: "p_star_c",
    zone: "air"
  }]
};
// 追加ステージ
const P = (id, zone) => ({
  id,
  zone
});
const MORE = [{
  name: "港町",
  bg: "bg_harbor",
  parts: [P("p_sailboat", "sea"), P("p_steamship", "sea"), P("p_lighthouse", "tree"), P("p_gull", "sky"), P("p_kikyu", "sky"), P("p_anchor", "ground"), P("p_barrel", "ground"), P("p_crab", "ground"), P("p_lifebuoy", "ground"), P("p_fishbox", "ground")]
}, {
  name: "駅のホーム",
  bg: "bg_station",
  parts: [P("p_train", "floor"), P("p_stclock", "wall"), P("p_poster", "wall"), P("p_signal", "tall"), P("p_gaslamp", "tall"), P("p_trunk", "floor"), P("p_bench", "floor"), P("p_pigeon", "floor"), P("p_tophat", "floor")]
}, {
  name: "海の中",
  bg: "bg_sea",
  parts: [P("p_fish_a", "water"), P("p_fish_b", "water"), P("p_jelly", "water"), P("p_turtle", "water"), P("p_octopus", "seabed"), P("p_starfish", "seabed"), P("p_shell", "seabed"), P("p_treasure", "seabed"), P("p_seaweed", "weed")]
}, {
  name: "台所",
  bg: "bg_kitchen",
  parts: [P("p_fpan", "wall"), P("p_ladle", "wall"), P("p_pot", "table"), P("p_kettle", "table"), P("p_bread", "table"), P("p_cheese", "table"), P("p_apple", "table"), P("p_teacup", "table"), P("p_cake", "table")]
}, {
  name: "お城の中庭",
  bg: "bg_castle",
  parts: [P("p_knight", "tall"), P("p_flagpole", "tree"), P("p_fountain", "ground"), P("p_cannon", "ground"), P("p_horse", "ground"), P("p_shield", "ground"), P("p_rosebush", "ground"), P("p_dragon", "sky"), P("p_owl", "sky")]
}, {
  name: "宇宙",
  bg: "bg_space",
  parts: [P("p_planet", "space"), P("p_rocket", "space"), P("p_ufo", "space"), P("p_astronaut", "space"), P("p_comet", "space"), P("p_satellite", "space"), P("p_alien", "surface"), P("p_moonflag", "surface"), P("p_rover", "surface")]
}, {
  name: "遊園地",
  bg: "bg_amuse",
  parts: [P("p_balloons", "sky"), P("p_firework", "sky"), P("p_booth", "tree"), P("p_merry", "tree"), P("p_icecream", "ground"), P("p_popcorn", "ground"), P("p_cotton", "ground"), P("p_cupride", "ground"), P("p_pinwheel", "ground")]
}, {
  name: "博士の研究室",
  bg: "bg_lab",
  parts: [P("p_map", "wall"), P("p_telescope", "tall"), P("p_globe", "floor"), P("p_microscope", "floor"), P("p_flask", "floor"), P("p_books", "floor"), P("p_candle", "floor"), P("p_hourglass", "floor"), P("p_puzzlebox", "floor")]
}, {
  name: "街角",
  bg: "bg_street",
  parts: [P("p_sign", "sky"), P("p_oldcar", "ground"), P("p_bicycle", "ground"), P("p_dog", "ground"), P("p_mailbox", "ground"), P("p_gaslamp", "tall"), P("p_umbrella", "ground"), P("p_flowerpot", "ground"), P("p_pigeon", "ground")]
}];
const ALL_SCENES = SCENES.concat([ROOM, CIRCUS], MORE);
// 置き場所の高さ(絵の中の中心のy)
const ZONE_Y = {
  sky: [55, 185],
  tree: [230, 300],
  ground: [335, 430],
  wall: [70, 210],
  tall: [300, 360],
  floor: [345, 420],
  air: [80, 190],
  stagetall: [270, 340],
  stage: [350, 420],
  sea: [250, 300],
  water: [70, 300],
  seabed: [385, 435],
  weed: [330, 380],
  table: [300, 430],
  space: [60, 320],
  surface: [395, 440]
};
function main(param) {
  const partIds = [];
  ALL_SCENES.forEach(s => s.parts.forEach(p => {
    if (partIds.indexOf(p.id) < 0) partIds.push(p.id);
  }));
  const scene = new g.Scene({
    game: g.game,
    assetIds: ["frame", "frame_s", "ghost", "dot", "logo", "pick", "put", "check", "great", "round", "beep", "go", "finish", "bgm", "kira0", "kira1", "kira2", "kira3", "kira4", "spark", "ring", "glow"].concat(partIds, ALL_SCENES.map(sc => sc.bg))
  });
  let time = 115;
  if (param.sessionParameter.totalTimeLimit) {
    time = param.sessionParameter.totalTimeLimit;
  }
  // ランキングモードでは g.game.vars.gameState.score をスコアとして扱う
  g.game.vars.gameState = {
    score: 0
  };
  scene.onLoad.add(() => {
    const dt = 1 / g.game.fps;
    const img = id => scene.asset.getImageById(id);
    const se = (id, vol = 0.8) => {
      scene.asset.getAudioById(id).play().changeVolume(vol);
    };
    const rand = () => param.random.generate();
    // ---- フォント(絵本のような、やさしい色) ----
    const makeFont = (color, stroke, sw = 8) => new g.DynamicFont({
      game: g.game,
      fontFamily: "sans-serif",
      fontWeight: "bold",
      size: 64,
      fontColor: color,
      strokeColor: stroke,
      strokeWidth: sw
    });
    const fontCream = makeFont("#fff6e0", "#5a3a1a");
    const fontGold = makeFont("#f2d48a", "#5a3a1a");
    const fontGreen = makeFont("#d8f4b0", "#2a5a1a");
    const label = (text, font, size, x, y, parent, align = "left") => {
      const l = new g.Label({
        scene,
        text,
        font,
        fontSize: size,
        x,
        y
      });
      if (align !== "left") l.anchorX = align === "center" ? 0.5 : 1;
      parent.append(l);
      return l;
    };
    const setText = (l, text) => {
      if (l.text !== text) {
        l.text = text;
        l.invalidate();
      }
    };
    const setImage = (s, asset) => {
      s.src = asset;
      s.width = s.srcWidth = asset.width;
      s.height = s.srcHeight = asset.height;
      s.invalidate();
    };
    const anims = [];
    const animate = (dur, fn, end) => {
      anims.push({
        t: 0,
        dur,
        fn,
        end
      });
    };
    const ease = p => 1 - Math.pow(1 - p, 3);
    // ---- レイヤー ----
    const bgLayer = new g.E({
      scene
    });
    const paintLayer = new g.E({
      scene,
      x: PX,
      y: PY
    }); // 絵を作る場所
    const uiLayer = new g.E({
      scene
    });
    const reviewLayer = new g.E({
      scene,
      x: PX,
      y: PY
    });
    const partLayer = new g.E({
      scene
    }); // パーツは画面の座標で動かす
    const fxLayer = new g.E({
      scene
    });
    const overLayer = new g.E({
      scene
    });
    [bgLayer, paintLayer, uiLayer, reviewLayer, partLayer, fxLayer, overLayer].forEach(e => scene.append(e));
    bgLayer.append(new g.FilledRect({
      scene,
      cssColor: "#3a2c22",
      width: 1280,
      height: 720
    }));
    // 木の床もよう
    for (let y = 0; y < 720; y += 36) {
      bgLayer.append(new g.FilledRect({
        scene,
        cssColor: "rgba(0,0,0,0.12)",
        y,
        width: 1280,
        height: 2
      }));
    }
    const tray = new g.FilledRect({
      scene,
      cssColor: "rgba(255,246,224,0.08)",
      x: 700,
      y: 300,
      width: 572,
      height: 412
    });
    bgLayer.append(tray);
    const paintBg = new g.Sprite({
      scene,
      src: img("bg_spring")
    });
    paintLayer.append(paintBg);
    uiLayer.append(new g.Sprite({
      scene,
      src: img("frame"),
      x: PX - 20,
      y: PY - 20
    }));
    const hintLabel = label("おてほんを見て、パーツを額縁に置こう", fontCream, 34, PX + PW / 2, 638, uiLayer, "center");
    const titleLabel = label("", fontGold, 40, PX + PW / 2, 46, uiLayer, "center");
    // おてほん
    const ref = new g.E({
      scene,
      x: RX,
      y: RY,
      scaleX: RS,
      scaleY: RS,
      anchorX: 0,
      anchorY: 0
    });
    const refBg = new g.Sprite({
      scene,
      src: img("bg_spring")
    });
    ref.append(refBg);
    const refParts = new g.E({
      scene
    });
    ref.append(refParts);
    uiLayer.append(ref);
    uiLayer.append(new g.Sprite({
      scene,
      src: img("frame_s"),
      x: RX - 10,
      y: RY - 10
    }));
    label("おてほん", fontGold, 26, RX + 160, RY + 248, uiLayer, "center");
    // 右上の情報
    label("のこり", fontCream, 26, 1166, 40, uiLayer, "center");
    const timeLabel = label("", fontCream, 64, 1166, 70, uiLayer, "center");
    const roundLabel = label("", fontGold, 28, 1166, 150, uiLayer, "center");
    label("とくてん", fontCream, 26, 1166, 196, uiLayer, "center");
    const scoreLabel = label("0", fontGold, 48, 1166, 226, uiLayer, "center");
    // ---- 状態 ----
    let phase = "intro";
    let elapsed = 0;
    let phaseT = 0;
    let round = 0; // 0 = 1枚目、1 = 2枚目、2 = 3枚目
    // 制限時間が短いときは、1枚あたりの時間を短くする
    // 制限時間が短いときは、どの絵の時間も同じ割合で短くする
    let need = INTRO_SEC + 6;
    ROUNDS.forEach(r => {
      need += r.sec + REVIEW_SEC + NEXT_SEC;
    });
    const timeRate = Math.min(1, time / need);
    const playSecOf = r => Math.max(8, ROUNDS[r].sec * timeRate);
    let playLeft = playSecOf(0);
    let score = 0;
    let parts = [];
    let reviewPanel = null;
    // 15種類の絵から、毎回ちがう3枚をえらぶ
    const sceneOrder = ALL_SCENES.slice();
    for (let i = sceneOrder.length - 1; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1));
      const t = sceneOrder[i];
      sceneOrder[i] = sceneOrder[j];
      sceneOrder[j] = t;
    }
    const sceneOf = r => sceneOrder[r];
    const slotPos = i => [TX + i % TCOLS * TCW + TCW / 2, TY + Math.floor(i / TCOLS) * TCH + TCH / 2];
    const trayScaleOf = s => Math.min(1, (TCW - 12) / s.width, (TCH - 30) / s.height);
    // おてほんの配置を作る(毎回ちがう)
    const setupRound = r => {
      var _a, _b;
      const sc = sceneOf(r);
      parts.forEach(p => p.sprite.destroy());
      parts = [];
      if (reviewPanel) reviewPanel.destroy();
      reviewPanel = null;
      (_a = refParts.children) === null || _a === void 0 ? void 0 : _a.slice().forEach(c => c.destroy());
      (_b = reviewLayer.children) === null || _b === void 0 ? void 0 : _b.slice().forEach(c => c.destroy());
      setImage(paintBg, img(sc.bg));
      setImage(refBg, img(sc.bg));
      setText(titleLabel, r + 1 + "枚目  " + sc.name);
      setText(roundLabel, r + 1 + "枚目 / " + ROUNDS.length + "枚");
      // 6〜8個を、ばらばらの順でえらぶ
      const pool = sc.parts.slice();
      for (let i = pool.length - 1; i > 0; i--) {
        const j = Math.floor(rand() * (i + 1));
        const t = pool[i];
        pool[i] = pool[j];
        pool[j] = t;
      }
      const n = Math.min(pool.length, ROUNDS[r].min + Math.floor(rand() * (ROUNDS[r].max - ROUNDS[r].min + 1)));
      const picked = pool.slice(0, n);
      const placed = []; // x, y, 半径
      picked.forEach((def, i) => {
        const a = img(def.id);
        const half = Math.max(a.width, a.height) / 2;
        const zy = ZONE_Y[def.zone];
        let best = [PW / 2, (zy[0] + zy[1]) / 2];
        let bestGap = -9999;
        for (let k = 0; k < 80; k++) {
          const x = a.width / 2 + 16 + rand() * (PW - a.width - 32);
          const y = Math.max(a.height / 2 + 8, Math.min(PH - a.height / 2 - 8, zy[0] + rand() * (zy[1] - zy[0])));
          // ほかのパーツとの重なりが、いちばん少ない場所をえらぶ
          let gap = 9999;
          placed.forEach(q => {
            gap = Math.min(gap, Math.sqrt((x - q[0]) * (x - q[0]) + (y - q[1]) * (y - q[1])) - (half + q[2]) * 0.7);
          });
          if (gap > bestGap) {
            bestGap = gap;
            best = [x, y];
          }
          if (gap > 0) break;
        }
        placed.push([best[0], best[1], half]);
        // おてほんに描く
        refParts.append(new g.Sprite({
          scene,
          src: a,
          x: best[0],
          y: best[1],
          anchorX: 0.5,
          anchorY: 0.5
        }));
        // 置き場のパーツ
        const s = new g.Sprite({
          scene,
          src: a,
          anchorX: 0.5,
          anchorY: 0.5,
          touchable: true
        });
        const part = {
          id: def.id,
          tx: best[0],
          ty: best[1],
          sprite: s,
          slot: i,
          placed: false,
          trayScale: trayScaleOf(s)
        };
        toTray(part, false);
        partLayer.append(s);
        bindDrag(part);
        parts.push(part);
      });
      // 置き場のマスの順番もばらばらにする
      const order = parts.map((_, i) => i);
      for (let i = order.length - 1; i > 0; i--) {
        const j = Math.floor(rand() * (i + 1));
        const t = order[i];
        order[i] = order[j];
        order[j] = t;
      }
      parts.forEach((p, i) => {
        p.slot = order[i];
        toTray(p, false);
      });
    };
    const toTray = (p, anim) => {
      const pos = slotPos(p.slot);
      p.placed = false;
      if (!anim) {
        p.sprite.x = pos[0];
        p.sprite.y = pos[1];
        p.sprite.scaleX = p.sprite.scaleY = p.trayScale;
        p.sprite.modified();
        return;
      }
      const sx = p.sprite.x,
        sy = p.sprite.y,
        ss = p.sprite.scaleX;
      animate(0.2, q => {
        const e = ease(q);
        p.sprite.x = sx + (pos[0] - sx) * e;
        p.sprite.y = sy + (pos[1] - sy) * e;
        p.sprite.scaleX = p.sprite.scaleY = ss + (p.trayScale - ss) * e;
        p.sprite.modified();
      });
    };
    // ---- ドラッグ ----
    let dragging = null;
    let gx = 0; // 指の位置(画面の座標)
    let gy = 0;
    const bindDrag = p => {
      const s = p.sprite;
      s.onPointDown.add(ev => {
        if (phase !== "play" || dragging) return;
        dragging = p;
        gx = s.x + (ev.point.x - s.width / 2) * s.scaleX;
        gy = s.y + (ev.point.y - s.height / 2) * s.scaleY;
        // いちばん手前に出して、実物大にする
        partLayer.remove(s);
        partLayer.append(s);
        s.scaleX = s.scaleY = 1;
        s.x = gx;
        s.y = gy;
        s.modified();
        se("pick", 0.5);
      });
      s.onPointMove.add(ev => {
        if (dragging !== p) return;
        gx += ev.prevDelta.x;
        gy += ev.prevDelta.y;
        s.x = gx;
        s.y = gy;
        s.modified();
      });
      s.onPointUp.add(() => {
        if (dragging !== p) return;
        dragging = null;
        drop(p);
      });
    };
    const drop = p => {
      const s = p.sprite;
      // 額縁の中なら置く。外なら置き場にもどす
      if (s.x > PX - 30 && s.x < PX + PW + 30 && s.y > PY - 30 && s.y < PY + PH + 30) {
        s.x = Math.max(PX, Math.min(PX + PW, s.x));
        s.y = Math.max(PY, Math.min(PY + PH, s.y));
        s.modified();
        p.placed = true;
        se("put", 0.6);
        animate(0.15, q => {
          s.scaleX = s.scaleY = 1 + 0.08 * Math.sin(q * Math.PI);
          s.modified();
        });
      } else {
        toTray(p, true);
      }
    };
    // ---- 答え合わせのエフェクト ----
    // 見た目だけに使う乱数(スコアや配置には影響しない)
    let fxSeed = 12345;
    const fxRand = () => {
      fxSeed = fxSeed * 1103515245 + 12345 & 0x7fffffff;
      return fxSeed / 0x7fffffff;
    };
    const fxSprite = (id, x, y) => {
      const s = new g.Sprite({
        scene,
        src: img(id),
        x,
        y,
        anchorX: 0.5,
        anchorY: 0.5
      });
      fxLayer.append(s);
      return s;
    };
    // 中心からキラキラを飛ばす
    const burst = (x, y, n, dist) => {
      for (let k = 0; k < n; k++) {
        const a = Math.PI * 2 * (k + fxRand() * 0.6) / n;
        const r = dist * (0.6 + fxRand() * 0.6);
        const sz = 0.5 + fxRand() * 0.6;
        const s = fxSprite("spark", x, y);
        animate(0.55 + fxRand() * 0.2, q => {
          const e = ease(q);
          s.x = x + Math.cos(a) * r * e;
          s.y = y + Math.sin(a) * r * e;
          s.scaleX = s.scaleY = sz * (1 - q * 0.7);
          s.angle = q * 180;
          s.opacity = q < 0.6 ? 1 : 1 - (q - 0.6) / 0.4;
          s.modified();
        }, () => s.destroy());
      }
    };
    // 広がる輪
    const ringFx = (x, y, size, dur) => {
      const s = fxSprite("ring", x, y);
      animate(dur, q => {
        s.scaleX = s.scaleY = size * (0.3 + ease(q) * 0.9);
        s.opacity = 1 - q;
        s.modified();
      }, () => s.destroy());
    };
    // ぽんっと出て、上にうかんで消える文字
    const popText = (text, font, size, x, y) => {
      const l = label(text, font, size, x, y, fxLayer, "center");
      l.anchorY = 0.5;
      animate(1.1, q => {
        const s = q < 0.15 ? 0.5 + q / 0.15 * 0.7 : q < 0.3 ? 1.2 - (q - 0.15) / 0.15 * 0.2 : 1;
        l.scaleX = l.scaleY = s;
        l.y = y - ease(q) * 40;
        l.opacity = q < 0.7 ? 1 : 1 - (q - 0.7) / 0.3;
        l.modified();
      }, () => l.destroy());
    };
    // パーツがぴょんとはねる
    const hop = (s, power) => {
      animate(0.35, q => {
        s.scaleX = s.scaleY = 1 + power * Math.sin(q * Math.PI);
        s.modified();
      }, () => {
        s.scaleX = s.scaleY = 1;
        s.modified();
      });
    };
    // コンボ中は、額縁のあちこちがさりげなくキラッと光る
    const twinkle = n => {
      for (let k = 0; k < n; k++) {
        const s = fxSprite("spark", PX + 20 + fxRand() * (PW - 40), PY + 20 + fxRand() * (PH - 40));
        const sz = 0.35 + fxRand() * 0.35;
        s.opacity = 0;
        s.modified();
        const delay = fxRand() * 0.5;
        animate(0.8 + delay, q => {
          const t = Math.max(0, (q * (0.8 + delay) - delay) / 0.8);
          s.scaleX = s.scaleY = sz * Math.sin(t * Math.PI);
          s.opacity = Math.sin(t * Math.PI) * 0.9;
          s.angle = t * 90;
          s.modified();
        }, () => s.destroy());
      }
    };
    const comboLabel = label("", fontGold, 36, PX + 4, PY + PH + 34, fxLayer);
    comboLabel.hide();
    const showCombo = n => {
      setText(comboLabel, n + "コンボ!");
      comboLabel.show();
      comboLabel.opacity = 1;
      animate(0.3, q => {
        comboLabel.scaleX = comboLabel.scaleY = 1 + 0.2 * Math.sin(q * Math.PI);
        comboLabel.modified();
      });
    };
    const hideCombo = () => {
      const startOp = comboLabel.opacity;
      animate(0.3, q => {
        comboLabel.opacity = startOp * (1 - q);
        comboLabel.modified();
      }, () => comboLabel.hide());
    };
    // ---- 答え合わせ ----
    const review = () => {
      phase = "review";
      phaseT = 0;
      if (dragging) {
        drop(dragging);
        dragging = null;
      }
      setText(hintLabel, "こたえあわせ");
      let total = 0;
      let accSum = 0;
      let combo = 0;
      // パーツ置き場の上に、1つずつ「点数とずれ」をならべる。置かなかったパーツは隠す
      parts.forEach(p => {
        if (!p.placed) p.sprite.hide();
      });
      const panel = new g.E({
        scene,
        x: 700,
        y: 316
      });
      fxLayer.append(panel);
      reviewPanel = panel;
      panel.append(new g.FilledRect({
        scene,
        cssColor: "#2e2219",
        width: 572,
        height: 400
      }));
      panel.append(new g.FilledRect({
        scene,
        cssColor: "rgba(242,212,138,0.5)",
        y: 340,
        width: 572,
        height: 2
      }));
      const rowH = Math.min(41, 328 / parts.length);
      const totalLabel = label("", fontGold, 40, 286, 348, panel, "center");
      parts.forEach((p, i) => {
        scene.setTimeout(() => {
          const ry = 8 + i * rowH;
          const icon = new g.Sprite({
            scene,
            src: img(p.id),
            x: 40,
            y: ry + rowH / 2,
            anchorX: 0.5,
            anchorY: 0.5
          });
          icon.scaleX = icon.scaleY = Math.min((rowH - 4) / icon.width, (rowH - 4) / icon.height);
          panel.append(icon);
          // おてほんの位置をうすく出して、置いた場所と線でつなぐ
          const ghost = new g.Sprite({
            scene,
            src: img(p.id),
            x: p.tx,
            y: p.ty,
            anchorX: 0.5,
            anchorY: 0.5
          });
          ghost.opacity = 0.45;
          reviewLayer.append(ghost);
          reviewLayer.append(new g.Sprite({
            scene,
            src: img("ghost"),
            x: p.tx,
            y: p.ty,
            anchorX: 0.5,
            anchorY: 0.5
          }));
          let pts = 0;
          let acc = 0;
          if (p.placed) {
            const px = p.sprite.x - PX,
              py = p.sprite.y - PY;
            const d = Math.sqrt((px - p.tx) * (px - p.tx) + (py - p.ty) * (py - p.ty));
            acc = Math.max(0, 1 - d / FULL_DIST);
            pts = Math.round(1000 * acc * acc);
            const steps = Math.floor(d / 10);
            for (let k = 1; k < steps; k++) {
              const dx = px + (p.tx - px) * k / steps,
                dy = py + (p.ty - py) * k / steps;
              reviewLayer.append(new g.Sprite({
                scene,
                src: img("dot"),
                x: dx,
                y: dy,
                anchorX: 0.5,
                anchorY: 0.5
              }));
            }
            // ずれを分かりやすく mm で出す(額縁の横幅640pxを、32cmの絵とみなす)
            const mm = Math.round(d * MM_PER_PX);
            const perfect = d < PERFECT_DIST;
            if (perfect) pts += 500;
            const font = perfect ? fontGold : pts >= 500 ? fontGreen : fontCream;
            label("ずれ " + mm + "mm", font, 28, 90, ry + rowH / 2 - 16, panel);
            label((perfect ? "ピッタリ! " : "") + "+" + pts + "点", font, 28, 550, ry + rowH / 2 - 16, panel, "right");
            // 合っているほど派手に。いい位置が続くとコンボになって、キラキラが増える
            const sx = p.sprite.x,
              sy = p.sprite.y;
            if (pts >= 500) {
              combo++;
              const lv = Math.min(4, combo - 1);
              se("kira" + lv, 0.5);
              if (perfect) {
                se("great", 0.6);
                const gl = fxSprite("glow", sx, sy);
                animate(0.7, q => {
                  gl.scaleX = gl.scaleY = 0.6 + ease(q) * 1.2;
                  gl.opacity = 1 - q;
                  gl.modified();
                }, () => gl.destroy());
                ringFx(sx, sy, 1.4, 0.6);
                burst(sx, sy, 12, 130);
                popText("ピッタリ!", fontGold, 52, sx, sy - 50);
                hop(p.sprite, 0.3);
              } else {
                ringFx(sx, sy, 1, 0.5);
                burst(sx, sy, 7, 90);
                popText(pts >= 800 ? "すごい!" : "いいね!", fontGreen, 44, sx, sy - 44);
                hop(p.sprite, 0.18);
              }
              if (combo >= 2) {
                showCombo(combo);
                twinkle(Math.min(14, combo * 2));
              }
            } else {
              if (combo >= 2) hideCombo();
              combo = 0;
              if (pts >= 150) {
                ringFx(sx, sy, 0.7, 0.4);
                popText("おしい!", fontCream, 36, sx, sy - 40);
              }
              se("check", 0.5);
            }
          } else {
            if (combo >= 2) hideCombo();
            combo = 0;
            label("置いてない", fontCream, 28, 90, ry + rowH / 2 - 16, panel);
            label("0点", fontCream, 28, 550, ry + rowH / 2 - 16, panel, "right");
            se("check", 0.3);
          }
          total += pts;
          accSum += acc;
          score += pts;
          g.game.vars.gameState.score = score; // 常に最新のスコアを入れておく
          setText(scoreLabel, String(score));
          if (i === parts.length - 1) {
            const rate = Math.round(accSum / parts.length * 100);
            setText(hintLabel, "そっくり度 " + rate + "%");
            setText(totalLabel, "この絵の点数  " + total + "点");
            se("round", 0.6);
          }
        }, 250 + i * 300);
      });
    };
    const startPlay = () => {
      phase = "play";
      phaseT = 0;
      playLeft = playSecOf(round);
      setText(hintLabel, "おてほんを見て、パーツを額縁に置こう");
      se("go", 0.6);
    };
    const nextRound = () => {
      round++;
      phase = "next";
      comboLabel.hide();
      phaseT = 0;
      setupRound(round);
      const box = new g.E({
        scene
      });
      overLayer.append(box);
      box.append(new g.FilledRect({
        scene,
        cssColor: "rgba(40,28,20,0.85)",
        y: 240,
        width: 1280,
        height: 240
      }));
      const sub = label("おてほんと同じ配置に置こう!", fontCream, 44, 640, 300, box, "center");
      sub.anchorY = 0.5;
      const l = label(round + 1 + "枚目  " + sceneOf(round).name, fontGold, 80, 640, 400, box, "center");
      l.anchorY = 0.5;
      animate(NEXT_SEC, q => {
        box.opacity = q < 0.8 ? 1 : 1 - (q - 0.8) / 0.2;
        box.modified();
      }, () => box.destroy());
    };
    const finish = () => {
      phase = "end";
      se("finish", 0.7);
      setText(hintLabel, "おしまい!  " + score + "点");
    };
    setupRound(0);
    // ---- イントロ ----
    const introLayer = new g.E({
      scene
    });
    overLayer.append(introLayer);
    introLayer.append(new g.FilledRect({
      scene,
      cssColor: "rgba(40,28,20,0.96)",
      width: 1280,
      height: 720
    }));
    const logo = new g.Sprite({
      scene,
      src: img("logo"),
      x: 640,
      y: 200,
      anchorX: 0.5,
      anchorY: 0.5
    });
    logo.scaleX = logo.scaleY = 0.85;
    introLayer.append(logo);
    label("おてほんと同じ場所に、パーツを置こう!", fontCream, 52, 640, 400, introLayer, "center");
    const countLabel = label("", fontGold, 96, 640, 600, introLayer, "center");
    countLabel.anchorY = 0.5;
    let lastCount = -1;
    const bgm = scene.asset.getAudioById("bgm");
    // ---- メインループ ----
    scene.onUpdate.add(() => {
      for (let i = anims.length - 1; i >= 0; i--) {
        const a = anims[i];
        a.t += dt;
        const p = Math.min(1, a.t / a.dur);
        a.fn(p);
        if (p >= 1) {
          anims.splice(i, 1);
          if (a.end) a.end();
        }
      }
      time -= dt;
      elapsed += dt;
      phaseT += dt;
      if (phase === "intro") {
        const c = Math.ceil(INTRO_SEC - elapsed);
        if (elapsed > INTRO_SEC - 3 && c !== lastCount && c > 0) {
          lastCount = c;
          setText(countLabel, String(c));
          se("beep", 0.35);
        }
        if (elapsed >= INTRO_SEC) {
          introLayer.destroy();
          bgm.play().changeVolume(0.35);
          startPlay();
        }
        setText(timeLabel, String(Math.ceil(playSecOf(0))));
        return;
      }
      if (phase === "play") {
        playLeft = Math.max(0, playLeft - dt);
        setText(timeLabel, String(Math.ceil(playLeft)));
        timeLabel.opacity = playLeft <= 5 && Math.floor(playLeft * 4) % 2 === 0 ? 0.5 : 1;
        timeLabel.modified();
        if (playLeft <= 0) review();
      } else if (phase === "review" && phaseT >= REVIEW_SEC) {
        if (round < ROUNDS.length - 1) nextRound();else finish();
      } else if (phase === "next" && phaseT >= NEXT_SEC) {
        startPlay();
      }
    });
  });
  g.game.pushScene(scene);
}
return module.exports;
},
},"parameterObject": {type:"script",path:"script/parameterObject.js",global:true,execute: rv => {
'use strict';
const module = rv.module;const exports = module.exports;const require = module.require;const __dirname = rv.dirname;const __filename = rv.filename;
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
return module.exports;
},
},}}