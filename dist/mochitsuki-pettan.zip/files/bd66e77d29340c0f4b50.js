module.exports={assets:{"_bootstrap": {type:"script",path:"script/_bootstrap.js",global:true,execute: rv => {
'use strict';
const module = rv.module;const exports = module.exports;const require = module.require;const __dirname = rv.dirname;const __filename = rv.filename;
"use strict";

// 通常このファイルを編集する必要はありません。ゲームの処理は main.js に記述してください
const main_1 = require("./main");
module.exports = originalParam => {
  const param = {};
  Object.keys(originalParam).forEach(key => {
    param[key] = originalParam[key];
  });
  // セッションパラメーター
  param.sessionParameter = {};
  // 乱数生成器
  param.random = g.game.random;
  const limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数
  const scene = new g.Scene({
    game: g.game,
    name: "_bootstrap"
  });
  // セッションパラメーターを受け取ってゲームを開始します
  scene.onMessage.add(msg => {
    if (msg.data && msg.data.type === "start" && msg.data.parameters) {
      param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加
      if (msg.data.parameters.randomSeed != null) {
        param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
      }
      g.game.popScene();
      (0, main_1.main)(param);
    }
  });
  scene.onLoad.add(() => {
    let currentTickCount = 0;
    scene.onUpdate.add(function () {
      currentTickCount++;
      // 待ち時間を超えた場合はゲームを開始します
      if (currentTickCount > limitTickToWait) {
        g.game.popScene();
        (0, main_1.main)(param);
      }
    });
  });
  g.game.pushScene(scene);
};
return module.exports;
},
},"main": {type:"script",path:"script/main.js",global:true,execute: rv => {
'use strict';
const module = rv.module;const exports = module.exports;const require = module.require;const __dirname = rv.dirname;const __filename = rv.filename;
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.main = main;
// ======== 調整用パラメータ ========
const W = 1280;
const H = 720;
const INTRO_SEC = 5;
const END_SEC = 3;
const FIRST_SEC = 1.2; // スタートしてから最初の印までの秒
const LEAD = 1.6; // 印がレーンの右はしから判定の輪までくる秒
// 判定: S=完璧 A=ほんの少しずれ B=ずれ F=完全にずれ(ミス)。数字はずれてよい幅(秒)
const S_W = 0.045;
const A_W = 0.09;
const B_W = 0.15;
const F_W = 0.22; // ここまでずれて押すとF。これより遠いと「スカッ」
const HAND_PRE = 0.12; // たぬきの手が臼に入っているあいだ(手の印の前後、秒)
const HAND_POST = 0.16;
const S_PT = 100;
const A_PT = 70;
const B_PT = 40;
const OUCH_PT = 300; // 手をついたときに引かれる点
const PER_MOCHI = 16; // これだけつくと、おもちが1つ完成
const MOCHI_PT = 500; // おもち完成のボーナス(+ ぴったり1回ごとに 50)
const RENDA_SEC = 0.09; // 連打パートで長押ししているとき、うさぎがつく間かく(秒)
const RENDA_PT = 30; // 連打1回の点
const JUDGE_X = 200; // 判定の輪の位置
const LANE_END = 1240;
const LANE_Y = 150;
const MOCHI_X = 640;
const MOCHI_Y = 540; // もちの下のはし
const STAGE_S = 0.85; // 舞台の大きさ
const SECTIONS = [{
  t: 0,
  bpm: 100,
  pats: ["ThThThTh"],
  name: "",
  rush: false
}, {
  t: 12,
  bpm: 116,
  pats: ["ThThThTh", "ThT.ThTT", "ThThTh.h", "RRRRRR.h"],
  name: "テンポアップ！",
  rush: false
}, {
  t: 24,
  bpm: 132,
  pats: ["ThThThTh", "ThT.ThTT", "Th.hThTh", "ThThh.Th", "RRRRRRRh"],
  name: "もっと速く！",
  rush: false
}, {
  t: 36,
  bpm: 148,
  pats: ["ThThThTh", "TTTTThTh", "Th.hThTh", "ThTh..Th", "ThT.ThTT", "RRRRR.hT"],
  name: "れんだも来るよ！",
  rush: false
}, {
  t: 48,
  bpm: 164,
  pats: ["TTTTThTh", "Th.hThTh", "ThT.ThTT", "ThThThTh", "TTThTTTh", "RRRRRR.h"],
  name: "大もちラッシュ！ 点数2ばい",
  rush: true
}];
const SONGS = [{
  name: "おめでた音頭",
  inst: "k",
  drum: "DkdkDkdk",
  mel: [5, -1, 4, 5, 7, -1, 5, -1, 4, -1, 2, 4, 5, -1, -1, -1, 3, -1, 4, 5, 4, -1, 2, -1, 1, -1, 2, 4, 2, -1, -1, -1, 5, -1, 7, 8, 7, -1, 5, 4, 5, -1, 7, -1, 9, -1, 8, 7, 5, -1, 4, 2, 4, -1, 5, -1, 2, -1, 1, -1, 0, -1, -1, -1]
}, {
  name: "ペッタンばやし",
  inst: "s",
  drum: "DkkdDkdk",
  mel: [2, 2, 4, -1, 5, 4, 2, -1, 4, 4, 5, -1, 7, 5, 4, -1, 5, 7, 8, 7, 5, -1, 4, -1, 2, 4, 2, -1, 0, -1, -1, -1, 2, 2, 4, -1, 5, 4, 2, -1, 4, 4, 5, -1, 7, 8, 9, -1, 8, 7, 5, 7, 8, -1, 7, -1, 5, 4, 2, 4, 5, -1, -1, -1]
}, {
  name: "はつひの笛",
  inst: "f",
  drum: "Dk.kdk.k",
  mel: [5, -1, -1, -1, 7, -1, 8, -1, 7, -1, 5, -1, 4, -1, -1, -1, 2, -1, 4, -1, 5, -1, 7, -1, 5, -1, -1, -1, -1, -1, -1, -1, 8, -1, -1, -1, 9, -1, 8, -1, 7, -1, 5, -1, 7, -1, -1, -1, 5, -1, 4, -1, 2, -1, 4, -1, 5, -1, -1, -1, -1, -1, -1, -1]
}, {
  name: "もちもち三味線",
  inst: "s",
  drum: "DkdkDddk",
  mel: [0, -1, 2, 0, 4, -1, 2, -1, 5, -1, 4, 2, 4, -1, -1, -1, 0, -1, 2, 0, 4, -1, 5, -1, 7, -1, 5, 4, 5, -1, -1, -1, 7, -1, 8, 7, 5, -1, 4, -1, 5, -1, 4, 2, 0, -1, 2, -1, 4, -1, 5, 4, 2, -1, 0, -1, 2, -1, -1, -1, 0, -1, -1, -1]
}, {
  name: "宝船のうた",
  inst: "k",
  drum: "DkkkDkdk",
  mel: [9, -1, 8, -1, 7, -1, 5, -1, 7, -1, 8, 9, 8, -1, -1, -1, 7, -1, 5, -1, 4, -1, 5, -1, 7, -1, -1, -1, -1, -1, -1, -1, 4, 5, 7, -1, 8, -1, 7, -1, 5, -1, 4, -1, 5, -1, 7, -1, 8, -1, 7, -1, 5, -1, 4, -1, 5, -1, -1, -1, -1, -1, -1, -1]
}, {
  name: "初夢しゃみせん",
  inst: "sk",
  drum: "DkDkdkDk",
  mel: [4, -1, 5, 7, 5, -1, 4, 2, 0, -1, 2, -1, 4, -1, -1, -1, 5, -1, 7, 8, 9, -1, 8, 7, 5, -1, 7, -1, 5, -1, -1, -1, 4, 4, 5, -1, 7, 7, 8, -1, 9, -1, 8, 7, 5, -1, 4, -1, 2, -1, 4, 5, 4, -1, 2, -1, 0, -1, -1, -1, -1, -1, -1, -1]
}, {
  name: "鶴と亀の笛",
  inst: "fk",
  drum: "Dk.kDkdk",
  mel: [7, -1, -1, 8, 9, -1, -1, -1, 8, -1, 7, -1, 5, -1, -1, -1, 4, -1, 5, -1, 7, -1, 5, -1, 4, -1, -1, -1, -1, -1, -1, -1, 9, -1, -1, 8, 7, -1, -1, -1, 5, -1, 7, -1, 8, -1, -1, -1, 7, -1, 5, -1, 4, -1, 2, -1, 4, -1, -1, -1, -1, -1, -1, -1]
}, {
  name: "門松ロック",
  inst: "s",
  drum: "DdkdDdkd",
  mel: [0, 0, 4, 0, 5, 0, 4, 2, 0, 0, 4, 0, 7, 5, 4, 2, 0, 0, 4, 0, 5, 0, 7, 8, 9, 8, 7, 5, 4, -1, 2, -1, 5, 5, 7, 5, 8, 5, 7, 5, 4, 4, 5, 4, 7, 4, 5, 4, 2, 2, 4, 2, 5, 4, 2, 0, 2, -1, 4, -1, 0, -1, -1, -1]
}, {
  name: "雪見の音頭",
  inst: "kkf",
  drum: "DkdkDkkk",
  mel: [2, -1, 4, -1, 5, -1, 4, 2, 4, -1, 5, -1, 7, -1, -1, -1, 8, -1, 7, -1, 5, -1, 7, 8, 7, -1, 5, -1, 4, -1, -1, -1, 2, -1, 4, -1, 5, -1, 7, 8, 9, -1, 8, -1, 7, -1, 5, -1, 4, -1, 5, 7, 5, -1, 4, -1, 2, -1, -1, -1, -1, -1, -1, -1]
}, {
  name: "ぽんぽこ大福",
  inst: "sf",
  drum: "DkkdDkkd",
  mel: [5, 4, 5, -1, 7, -1, 5, -1, 4, 2, 4, -1, 5, -1, -1, -1, 7, 8, 7, -1, 5, -1, 4, -1, 5, 4, 2, -1, 0, -1, -1, -1, 5, 4, 5, -1, 7, -1, 8, -1, 9, 8, 9, -1, 8, -1, 7, -1, 5, 7, 8, -1, 7, -1, 5, -1, 4, 2, 4, -1, 5, -1, -1, -1]
}];
// 背景は5つ(空はゲームが時間帯ごとに描く)
const THEMES = [{
  id: "asa",
  name: "富士の見える神社"
}, {
  id: "yuki",
  name: "雪の神社"
}, {
  id: "ume",
  name: "梅の庭"
}, {
  id: "yuu",
  name: "城下町"
}, {
  id: "takara",
  name: "宝船のうたげ"
}];
const TIMES = [{
  name: "朝",
  sky: ["#7aa8f0", "#ffc8a8", "#ffe8b8"],
  tint: [255, 190, 140, 0.1]
}, {
  name: "昼",
  sky: ["#3a96f0", "#86ccff", "#d8f4ff"],
  tint: [255, 255, 255, 0]
}, {
  name: "夕方",
  sky: ["#5a3a8a", "#ff7a5a", "#ffc870"],
  tint: [255, 110, 60, 0.18]
}, {
  name: "夜",
  sky: ["#0a1238", "#1e2c66", "#3a4a86"],
  tint: [20, 30, 90, 0.4]
}];
const SHOT_SEC = 10; // カメラを切りかえる間かく(秒)
const UP_ZOOM = 1.75; // アップのときの大きさ
// 点数でもらえる称号(上から順に見て、点数がこえていればそれ)
const TITLES = [[55000, "神の餅つき師"], [48000, "伝説のペッタン名人"], [42000, "餅つき横綱"], [36000, "杵さばきの達人"], [30000, "もち屋の看板うさぎ"], [24000, "町内の餅つき番長"], [18000, "見習い餅つき職人"], [12000, "ペッタン一年生"], [6000, "きなこまみれの新人"], [0, "臼のまわりの見物人"]];
const MOCHI_TYPES = ["m_kin", "m_kouhaku", "m_kinako", "m_anko", "m_kusa"];
const MOCHI_NAMES = ["金ぱくもち", "紅白もち", "きなこもち", "あんこもち", "草もち"];
class View extends g.E {
  constructor() {
    super(...arguments);
    this.draw = () => undefined;
  }
  renderSelf(r) {
    this.draw(r);
    return true;
  }
}
function main(param) {
  const imageIds = ["note_renda", "usagi_joy", "usagi_sad", "tanuki_joy", "tanuki_sad", "medal_s", "medal_a", "medal_b", "medal_f", "title_ribbon", "crowd0", "crowd1", "kadomatsu", "glow", "rays", "ov_crowd0", "ov_crowd1", "ov_usu", "ov_mochi", "ov_usagi", "ov_kine", "ov_tanuki", "ov_arm", "usu", "usu_front", "mochi", "usagi_up", "usagi_mid", "usagi_down", "tanuki_idle", "tanuki_hand", "tanuki_ouch", "note_tsuki", "note_te", "judge", "ring", "tray", "spark", "star", "splash", "logo"].concat(MOCHI_TYPES, THEMES.map(t => "bg_" + t.id), THEMES.map(t => "ov_" + t.id));
  const audioIds = ["don", "ka", "cue", "pettan", "perfect", "good", "miss", "ouch", "hai", "complete", "count", "go", "finish", "rush", "cheer"];
  for (let i = 0; i < 10; i++) audioIds.push("k" + i, "s" + i, "f" + i);
  const scene = new g.Scene({
    game: g.game,
    assetIds: imageIds.concat(audioIds.map(a => "se_" + a))
  });
  let time = 70;
  if (param.sessionParameter.totalTimeLimit) time = param.sessionParameter.totalTimeLimit;
  // ランキングモードでは g.game.vars.gameState.score をスコアとして扱う
  g.game.vars.gameState = {
    score: 0
  };
  scene.onLoad.add(() => {
    const dt = 1 / g.game.fps;
    const rand = () => param.random.generate();
    const img = id => scene.asset.getImageById(id);
    const surf = {};
    imageIds.forEach(id => {
      surf[id] = g.SurfaceUtil.asSurface(img(id));
    });
    const se = (id, vol = 0.6) => {
      scene.asset.getAudioById("se_" + id).play().changeVolume(vol);
    };
    const playSec = Math.max(30, time - INTRO_SEC - END_SEC);
    // ======== 譜面: 参加者みんな同じ ========
    const evs = [];
    const slots = [];
    const sectionAt = t => {
      let s = SECTIONS[0];
      SECTIONS.forEach(q => {
        if (t >= q.t * playSec / 62) s = q;
      });
      return s;
    };
    {
      let t = FIRST_SEC;
      let idx = 0;
      let bar = 0;
      let lastSec = -1;
      let barInSec = 0;
      while (t < playSec - 0.8) {
        const sec = sectionAt(t);
        const slot = 60 / sec.bpm / 2;
        // 区間に入って3小節めは、かならず連打(連打のある区間だけ)
        const si = SECTIONS.indexOf(sec);
        if (si !== lastSec) {
          lastSec = si;
          barInSec = 0;
        }
        const renda = sec.pats.filter(q => q.charAt(0) === "R");
        let pat = bar < 2 ? sec.pats[0] : sec.pats[Math.floor(rand() * sec.pats.length)];
        if (barInSec === 2 && renda.length > 0) pat = renda[0];
        barInSec++;
        for (let k = 0; k < 8 && t < playSec - 0.8; k++) {
          const c = pat.charAt(k);
          if (c === "T" || c === "h") evs.push({
            t,
            t2: t,
            kind: c,
            done: false,
            res: "",
            rush: sec.rush
          });
          if (c === "R" && (k === 0 || pat.charAt(k - 1) !== "R")) {
            let n = 0;
            while (pat.charAt(k + n) === "R") n++;
            evs.push({
              t,
              t2: t + slot * n,
              kind: "R",
              done: false,
              res: "",
              rush: sec.rush
            });
          }
          slots.push({
            t,
            idx: idx++,
            beat: k % 2 === 0,
            rush: sec.rush
          });
          t += slot;
        }
        bar++;
      }
    }
    // 曲と背景は、ゲームごとにランダム
    const song = SONGS[Math.floor(rand() * SONGS.length)];
    const theme = THEMES[Math.floor(rand() * THEMES.length)];
    // ======== 状態 ========
    let phase = "intro";
    let introLeft = INTRO_SEC;
    let now = 0; // 曲の時間(秒)
    let score = 0;
    let combo = 0;
    let maxCombo = 0;
    let hits = 0; // いまのおもちを何回ついたか
    let perfectsInMochi = 0; // S は1、A は0.5 として数える(おもちの豪華さ)
    const ranks = {
      S: 0,
      A: 0,
      B: 0,
      F: 0
    };
    const made = []; // 完成したおもちの種類
    let slotIdx = 0;
    let lastBeat = -9;
    let lastHit = -9; // うさぎが杵をおろした時刻
    let ouchT = 0;
    let squash = 0;
    let shake = 0;
    let flash = 0;
    let flashCol = "#ffffff";
    let crowdT = 0;
    let cheer = 0;
    let sectionName = "";
    let glowT = 0; // おもち完成の光
    let lastTen = false;
    let rollT = 0;
    let rollTick = 0;
    let held = false; // 画面を押しているか
    let heldFromRenda = false; // 連打のときから押しっぱなし
    let rendaTimer = 0;
    let rendaCount = 0;
    let rendaPts = 0;
    let shot = 0; // 0=いつもの 1=アップ 2=俯瞰
    let todIdx = 0;
    const parts = [];
    const fxs = [];
    let punch = 0; // S のときに画面がドンとはずむ
    let judgeShake = 0; // F のときに判定の輪がぶるっとする
    let sStreak = 0;
    // ======== 絵 ========
    const view = new View({
      scene,
      width: W,
      height: H
    });
    scene.append(view);
    // いま連打パートの中なら、その印
    const rendaNow = () => {
      for (let i = 0; i < evs.length; i++) {
        const e = evs[i];
        if (e.kind === "R" && now >= e.t - 0.05 && now <= e.t2) return e;
        if (e.t > now + 1) break;
      }
      return null;
    };
    const nextT = () => {
      for (let i = 0; i < evs.length; i++) if (!evs[i].done && evs[i].kind === "T" && evs[i].t > now - F_W) return evs[i];
      return null;
    };
    // たぬきの手が臼に入っていれば、その手の印までの近さ(秒)。入っていなければ -1
    const handNear = () => {
      for (let i = 0; i < evs.length; i++) {
        const e = evs[i];
        if (e.kind === "h" && now >= e.t - HAND_PRE && now <= e.t + HAND_POST) return Math.abs(e.t - now);
        if (e.t > now + 1) break;
      }
      return -1;
    };
    const handIn = () => handNear() >= 0;
    const slotLen = () => 60 / sectionAt(now).bpm / 2;
    const drawImg = (r, id, x, y, sx = 1, sy = 1, alpha = 1) => {
      const a = img(id);
      r.save();
      if (alpha < 1) r.opacity(alpha);
      r.transform([sx, 0, 0, sy, x, y]);
      r.drawImage(surf[id], 0, 0, a.width, a.height, 0, 0);
      r.restore();
    };
    // ---- 時間帯: 朝→昼→夕方→夜 ----
    const hex = c => {
      const n = parseInt(c.slice(1), 16);
      return [n >> 16 & 255, n >> 8 & 255, n & 255];
    };
    const mix3 = (a, b, t) => [0, 1, 2].map(i => a[i] + (b[i] - a[i]) * t);
    const rgb = c => "rgb(" + c.map(v => Math.round(v)).join(",") + ")";
    // いまの時間帯(0〜3)と、次の時間帯へのうつりかわり(0〜1)
    const todNow = () => {
      const f = Math.max(0, Math.min(3.999, now / playSec * 4));
      const i = Math.floor(f),
        fr = f - i;
      return {
        i,
        t: i < 3 ? Math.max(0, (fr - 0.85) / 0.15) : 0
      };
    };
    const drawSky = r => {
      const td = todNow(),
        a = TIMES[td.i],
        b = TIMES[Math.min(3, td.i + 1)];
      const N = 18;
      for (let k = 0; k < N; k++) {
        const v = k / (N - 1) * 2;
        const ia = Math.min(1, Math.floor(v)),
          fv = v - ia;
        const ca = mix3(hex(a.sky[ia]), hex(a.sky[ia + 1]), fv),
          cb = mix3(hex(b.sky[ia]), hex(b.sky[ia + 1]), fv);
        const col = rgb(mix3(ca, cb, td.t));
        r.fillRect(0, k * 440 / N, W, 440 / N + 1, col);
      }
      const p = Math.min(1, now / playSec);
      // お日さま(朝にのぼって夕方にしずむ)
      if (p < 0.8) {
        const q = p / 0.75;
        const x = 160 + q * 960,
          y = 360 - Math.sin(Math.min(1, q) * Math.PI) * 280;
        r.save();
        r.opacity(Math.max(0, Math.min(1, (0.8 - p) * 10)));
        const gl = img("glow");
        r.transform([0.6, 0, 0, 0.6, x - gl.width * 0.3, y - gl.height * 0.3]);
        r.drawImage(surf.glow, 0, 0, gl.width, gl.height, 0, 0);
        r.restore();
        r.save();
        r.opacity(Math.max(0, Math.min(1, (0.8 - p) * 10)));
        r.fillRect(x - 46, y - 46, 92, 92, p > 0.55 ? "#ff8a4a" : "#fff0a0");
        r.restore();
      }
      // 夜: 月と星
      if (p > 0.72) {
        const al = Math.min(1, (p - 0.72) * 8);
        r.save();
        r.opacity(al);
        for (let k = 0; k < 40; k++) {
          const sx2 = k * 197 % W,
            sy2 = k * 83 % 330,
            tw = 2 + k * 7 % 3;
          r.fillRect(sx2, sy2, tw, tw, "#fff8d0");
        }
        r.fillRect(980, 80, 70, 70, "#fff8d8");
        r.fillRect(1004, 80, 46, 46, TIMES[3].sky[0]);
        r.restore();
      }
    };
    const drawTint = r => {
      const td = todNow(),
        a = TIMES[td.i].tint,
        b = TIMES[Math.min(3, td.i + 1)].tint;
      const m = k => a[k] + (b[k] - a[k]) * td.t;
      if (m(3) <= 0.001) return;
      r.save();
      r.opacity(m(3));
      r.fillRect(0, 0, W, H, "rgb(" + Math.round(m(0)) + "," + Math.round(m(1)) + "," + Math.round(m(2)) + ")");
      r.restore();
    };
    // ---- おもち完成の光(臼のうしろで回る光の筋と、臼をつつむ光) ----
    const drawGlow = (r, cx, cy, s) => {
      if (glowT <= 0) return;
      const a = Math.min(1, glowT);
      const ry = img("rays"),
        gl = img("glow");
      const rot = now * 1.5,
        rs = s * (1.1 + (1.6 - glowT) * 0.3);
      r.save();
      r.setCompositeOperation("lighter");
      r.opacity(a * 0.9);
      const c = Math.cos(rot) * rs,
        si = Math.sin(rot) * rs;
      r.transform([c, si, -si, c, cx, cy]);
      r.drawImage(surf.rays, 0, 0, ry.width, ry.height, -ry.width / 2, -ry.height / 2);
      r.setCompositeOperation("source-over");
      r.restore();
      r.save();
      r.setCompositeOperation("lighter");
      r.opacity(a * (0.6 + Math.sin(now * 20) * 0.2));
      r.transform([s * 1.3, 0, 0, s * 0.9, cx - gl.width * s * 0.65, cy - gl.height * s * 0.45]);
      r.drawImage(surf.glow, 0, 0, gl.width, gl.height, 0, 0);
      r.setCompositeOperation("source-over");
      r.restore();
    };
    const drawParts = r => {
      parts.forEach(p => {
        r.save();
        r.opacity(Math.min(1, p.life / p.max * 2));
        if (p.img) {
          const a = img(p.img);
          const s = p.size / a.width;
          r.transform([s * Math.cos(p.spin), s * Math.sin(p.spin), -s * Math.sin(p.spin), s * Math.cos(p.spin), p.x, p.y]);
          r.drawImage(surf[p.img], 0, 0, a.width, a.height, -a.width / 2, -a.height / 2);
        } else {
          r.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size, p.col);
        }
        r.restore();
      });
    };
    const drawRing = (r, cx, cy, base) => {
      const n = nextT();
      if (!n || phase !== "play") return;
      const k = (n.t - now) / (slotLen() * 2);
      if (k <= -0.1 || k >= 1) return;
      const s = base * (0.28 + Math.max(0, k) * 0.9);
      const a = img("ring");
      drawImg(r, "ring", cx - a.width * s / 2, cy - a.height * s / 2, s, s, Math.min(1, (1 - k) * 2));
    };
    // 観客のジャンプ(おもち完成のとき)
    const crowdJump = () => glowT > 0 ? -Math.abs(Math.sin(glowT * 14)) * 34 * Math.min(1, glowT) : 0;
    // ---- 横から見た画面(いつもの・アップ) ----
    const drawSide = r => {
      drawImg(r, "bg_" + theme.id, 0, 0);
      drawImg(r, "crowd" + Math.floor(crowdT) % 2, 0, 318 + crowdJump());
      // 門松は観客の手前
      drawImg(r, "kadomatsu", -20, 330);
      drawImg(r, "kadomatsu", 1080, 330);
      // 舞台(臼・もち・うさぎ・たぬき)は少し小さく、画面の下はしを中心にちぢめる
      r.save();
      r.transform([STAGE_S, 0, 0, STAGE_S, W / 2 * (1 - STAGE_S), H * (1 - STAGE_S)]);
      drawGlow(r, MOCHI_X, 520, 1);
      drawImg(r, "usu", MOCHI_X - 230, 470);
      const grow = 0.72 + 0.4 * Math.min(1, hits / PER_MOCHI);
      const sq = Math.max(0, squash);
      const mw = 300 * grow * (1 + sq * 0.35),
        mh = 170 * grow * (1 - sq * 0.45);
      drawImg(r, "mochi", MOCHI_X - mw / 2, MOCHI_Y - mh, mw / 300, mh / 170);
      drawImg(r, "usu_front", MOCHI_X - 230, 530);
      if (glowT > 0) {
        // 臼のふちが金色に光る
        r.save();
        r.setCompositeOperation("lighter");
        r.opacity(Math.min(1, glowT) * 0.55);
        drawImg(r, "usu", MOCHI_X - 230, 470);
        r.setCompositeOperation("source-over");
        r.restore();
      }
      drawImg(r, rabbitPose(), 230, 63 + (glowT > 0 ? crowdJump() * 0.5 : 0));
      const tid = ouchT > 0 ? "tanuki_ouch" : handIn() ? "tanuki_hand" : "tanuki_idle";
      drawImg(r, tid, 640, 90 + (glowT > 0 && ouchT <= 0 ? crowdJump() * 0.5 : 0));
      // 完成したおもち(おぼんの上に積む)
      drawImg(r, "tray", 1010, 650);
      made.forEach((m, i) => {
        const col = i % 2,
          row = Math.floor(i / 2);
        if (row > 4) return;
        drawImg(r, MOCHI_TYPES[m], 1040 + col * 100 + row % 2 * 30, 590 - row * 56, 0.8, 0.8);
      });
      drawRing(r, MOCHI_X, MOCHI_Y - 70, 1);
      drawParts(r);
      r.restore();
    };
    const rabbitPose = () => {
      const n = nextT();
      if (now - lastHit < (rendaNow() ? 0.05 : 0.12)) return "usagi_down";
      if (phase === "play" && n && n.t - now < slotLen() * 1.1) return "usagi_up";
      return "usagi_mid";
    };
    // ---- 上から見た画面(俯瞰) ----
    const OV_X = 640,
      OV_Y = 450;
    const drawOver = r => {
      drawImg(r, "ov_" + theme.id, 0, 0);
      drawGlow(r, OV_X, OV_Y, 1.1);
      const u = img("ov_usu");
      drawImg(r, "ov_usu", OV_X - u.width / 2, OV_Y - u.height / 2);
      const grow = 0.6 + 0.35 * Math.min(1, hits / PER_MOCHI);
      const sq = Math.max(0, squash);
      const ms = grow * (1 + sq * 0.25);
      const mo = img("ov_mochi");
      drawImg(r, "ov_mochi", OV_X - mo.width * ms / 2, OV_Y - mo.height * ms / 2, ms, ms);
      if (glowT > 0) {
        r.save();
        r.setCompositeOperation("lighter");
        r.opacity(Math.min(1, glowT) * 0.5);
        drawImg(r, "ov_usu", OV_X - u.width / 2, OV_Y - u.height / 2);
        r.setCompositeOperation("source-over");
        r.restore();
      }
      drawRing(r, OV_X, OV_Y, 1);
      // うさぎと杵(上げているほど、カメラに近くて大きい)
      const us = img("ov_usagi");
      const hop = glowT > 0 ? crowdJump() * 0.3 : 0;
      drawImg(r, "ov_usagi", 330 - us.width / 2, OV_Y - us.height / 2 + hop);
      const pose = rabbitPose();
      const ks = pose === "usagi_down" ? 1 : pose === "usagi_up" ? 1.4 : 1.18;
      const kx = pose === "usagi_down" ? OV_X - 245 : pose === "usagi_up" ? 360 : 380;
      const ka = pose === "usagi_down" ? 0 : pose === "usagi_up" ? -0.18 : -0.08;
      const ki = img("ov_kine");
      r.save();
      const c = Math.cos(ka) * ks,
        si = Math.sin(ka) * ks;
      r.transform([c, si, -si, c, kx, OV_Y]);
      r.drawImage(surf.ov_kine, 0, 0, ki.width, ki.height, -10, -ki.height / 2);
      r.restore();
      // たぬきと手
      const tn = img("ov_tanuki"),
        ar = img("ov_arm");
      const shake2 = ouchT > 0 ? Math.sin(now * 60) * 8 : 0;
      const reach = handIn() ? 0.95 : 0.4;
      r.save();
      r.transform([reach, 0, 0, 1, 930 - ar.width * reach, OV_Y - 60 - ar.height / 2]);
      r.drawImage(surf.ov_arm, 0, 0, ar.width, ar.height, 0, 0);
      r.restore();
      drawImg(r, "ov_tanuki", 990 - tn.width / 2 + shake2, OV_Y - tn.height / 2 + (glowT > 0 && ouchT <= 0 ? hop : 0));
      if (ouchT > 0) {
        for (let k = 0; k < 3; k++) {
          const t = now * 9 + k * 2.1,
            st = img("star");
          drawImg(r, "star", 960 + Math.cos(t) * 70 - st.width / 2, OV_Y - 20 + Math.sin(t) * 40 - st.height / 2);
        }
      }
      // まわりの観客
      const cs = 1 + (glowT > 0 ? Math.abs(Math.sin(glowT * 14)) * 0.02 : 0);
      drawImg(r, "ov_crowd" + Math.floor(crowdT) % 2, W / 2 * (1 - cs), H / 2 * (1 - cs), cs, cs);
      // 完成したおもち
      made.forEach((m, i) => {
        if (i > 9) return;
        drawImg(r, MOCHI_TYPES[m], 1150 - i % 5 * 70, 560 + Math.floor(i / 5) * 56, 0.6, 0.6);
      });
      drawParts(r);
    };
    // カメラ: いつもの / アップ(もちに寄る) / 俯瞰
    const camMat = () => {
      if (shot !== 1) return [1, 0, 0, 1, 0, 0];
      const fx = W / 2,
        fy = H * (1 - STAGE_S) + 500 * STAGE_S;
      return [UP_ZOOM, 0, 0, UP_ZOOM, W / 2 - fx * UP_ZOOM, 450 - fy * UP_ZOOM];
    };
    view.draw = r => {
      drawSky(r);
      r.save();
      if (shake > 0) r.translate(Math.sin(shake * 70) * shake * 18, Math.cos(shake * 53) * shake * 10);
      if (punch > 0) {
        const k = 1 + punch * 0.06;
        r.transform([k, 0, 0, k, W / 2 * (1 - k), H * 0.62 * (1 - k)]);
      }
      if (shot === 2) {
        drawOver(r);
      } else {
        r.transform(camMat());
        drawSide(r);
      }
      r.restore();
      drawTint(r);
      // レーン
      r.save();
      r.opacity(0.75);
      r.fillRect(110, LANE_Y - 48, LANE_END - 80, 96, "#3a1e2a");
      r.restore();
      r.fillRect(110, LANE_Y - 48, LANE_END - 80, 4, "#ffd040");
      r.fillRect(110, LANE_Y + 44, LANE_END - 80, 4, "#ffd040");
      const jd = img("judge");
      const pulse = 1 + Math.max(0, 0.15 - (now - lastBeat)) * 1.2; // 太鼓に合わせてふくらむ
      const jsx = judgeShake > 0 ? Math.sin(judgeShake * 80) * judgeShake * 30 : 0;
      drawImg(r, "judge", JUDGE_X - jd.width * pulse / 2 + jsx, LANE_Y - jd.height * pulse / 2, pulse, pulse);
      for (let i = evs.length - 1; i >= 0; i--) {
        const e = evs[i];
        const dtt = e.t - now;
        if (dtt > LEAD || (e.kind === "R" ? e.t2 - now < -0.1 : dtt < -0.4)) continue;
        if (e.kind === "T" && e.done) continue;
        const x = JUDGE_X + dtt / LEAD * (LANE_END - JUDGE_X);
        if (e.kind === "R") {
          // 連打の帯: 先頭の印から終わりまで
          const x1 = Math.max(JUDGE_X, x),
            x2 = Math.min(LANE_END, JUDGE_X + (e.t2 - now) / LEAD * (LANE_END - JUDGE_X));
          if (x2 > x1) {
            r.fillRect(x1, LANE_Y - 30, x2 - x1, 60, "#3a1e2a");
            r.fillRect(x1, LANE_Y - 24, x2 - x1, 48, "#ffb020");
            r.fillRect(x1, LANE_Y - 18, x2 - x1, 12, "#fff27a");
            const re = img("note_renda");
            drawImg(r, "note_renda", x2 - re.width * 0.5, LANE_Y - re.height * 0.4, 0.8, 0.8);
          }
          const re = img("note_renda");
          drawImg(r, "note_renda", x1 - re.width * 0.45, LANE_Y - re.height * 0.45, 0.9, 0.9);
          continue;
        }
        const id = e.kind === "T" ? "note_tsuki" : "note_te";
        const s = e.kind === "T" ? 0.9 : 0.72;
        const a = img(id);
        drawImg(r, id, x - a.width * s / 2, LANE_Y - a.height * s / 2, s, s, dtt < 0 ? Math.max(0, 1 + dtt * 3) : 1);
      }
      fxs.forEach(f => {
        const t = 1 - f.life / f.max;
        r.save();
        if (f.kind === "ring") {
          // ひろがる輪
          const a = img("ring"),
            sc = f.size * (0.4 + t * 1.0) / a.width;
          r.opacity(Math.max(0, 1 - t) * 0.95);
          r.setCompositeOperation("lighter");
          r.transform([sc, 0, 0, sc, f.x - a.width * sc / 2, f.y - a.height * sc / 2]);
          r.drawImage(surf.ring, 0, 0, a.width, a.height, 0, 0);
          r.setCompositeOperation("source-over");
        } else if (f.kind === "rays") {
          const a = img("rays"),
            sc = f.size / a.width * (0.6 + t * 0.6),
            rot = t * 1.2;
          r.opacity(Math.max(0, 1 - t) * 0.9);
          r.setCompositeOperation("lighter");
          const c = Math.cos(rot) * sc,
            si = Math.sin(rot) * sc;
          r.transform([c, si, -si, c, f.x, f.y]);
          r.drawImage(surf.rays, 0, 0, a.width, a.height, -a.width / 2, -a.height / 2);
          r.setCompositeOperation("source-over");
        } else if (f.kind === "smoke") {
          const z = f.size * (0.25 + t * 0.4);
          r.opacity(Math.max(0, 1 - t) * 0.55);
          r.fillRect(f.x - z / 2, f.y - z / 2, z, z, f.col);
        } else {
          r.opacity(Math.min(1, f.life / f.max * 2));
          r.fillRect(f.x - f.size / 2, f.y - f.size / 2, f.size, f.size, f.col);
        }
        r.restore();
      });
      if (flash > 0) {
        r.save();
        r.opacity(Math.min(0.5, flash));
        r.fillRect(0, 0, W, H, flashCol);
        r.restore();
      }
      if (phase === "play" && now >= playSec - 10 && Math.floor(now * 4) % 2 === 0) {
        r.save();
        r.opacity(0.75);
        r.fillRect(0, 0, W, 14, "#ff3a3a");
        r.fillRect(0, H - 14, W, 14, "#ff3a3a");
        r.fillRect(0, 0, 14, H, "#ff3a3a");
        r.fillRect(W - 14, 0, 14, H, "#ff3a3a");
        r.restore();
      }
    };
    // ======== 文字 ========
    const font = (color, stroke, sw = 8) => new g.DynamicFont({
      game: g.game,
      fontFamily: "sans-serif",
      fontWeight: "bold",
      size: 72,
      fontColor: color,
      strokeColor: stroke,
      strokeWidth: sw
    });
    const fontW = font("#ffffff", "#3a1e2a");
    const fontY = font("#ffe840", "#3a1e2a");
    const fontR = font("#ff5a6a", "#ffffff");
    const fontP = font("#ff8ad8", "#ffffff");
    const fontC = font("#70e8ff", "#3a1e2a");
    const label = (f, size, x, y, text, align = "left", parent) => {
      const l = new g.Label({
        scene,
        font: f,
        fontSize: size,
        text,
        x,
        y,
        width: 1240,
        textAlign: align,
        widthAutoAdjust: false
      });
      if (align === "center") l.x = x - 620;
      if (align === "right") l.x = x - 1240;
      (parent || scene).append(l);
      return l;
    };
    const setText = (l, t) => {
      if (l.text !== t) {
        l.text = t;
        l.invalidate();
      }
    };
    const scoreLabel = label(fontW, 44, 20, 18, "0てん");
    const timeLabel = label(fontW, 44, W - 24, 18, "", "right");
    const comboLabel = label(fontY, 36, 20, 300, "");
    const mochiLabel = label(fontY, 32, W - 24, 70, "", "right");
    const todLabel = label(fontC, 30, W - 24, 108, "", "right");
    const pops = [];
    const popText = (t, f, size, x, y, life = 0.8) => {
      const l = label(f, size, x, y, t, "center");
      l.anchorX = 0.5;
      l.anchorY = 0.5;
      l.x = x;
      l.y = y + size / 2;
      pops.push({
        l,
        life,
        vy: -60,
        scale: 1.4
      });
    };
    // ======== はじめの説明 ========
    const intro = new g.E({
      scene
    });
    scene.append(intro);
    intro.append(new g.FilledRect({
      scene,
      cssColor: "rgba(40,16,30,0.62)",
      width: W,
      height: H
    }));
    intro.append(new g.Sprite({
      scene,
      src: img("logo"),
      x: W / 2,
      y: 140,
      anchorX: 0.5,
      anchorY: 0.5,
      scaleX: 0.52,
      scaleY: 0.52
    }));
    label(fontW, 30, W / 2, 262, "上のレーンの「おもち」が輪にかさなったら、タップでペッタン！", "center", intro);
    label(fontC, 30, W / 2, 304, "「たぬきの手」のときは押しちゃダメ！ 手をついちゃうよ", "center", intro);
    label(fontY, 30, W / 2, 346, "16回つくと おもち完成！ Sが多いほど豪華なおもちに", "center", intro);
    label(fontP, 30, W / 2, 388, "黄色い帯は長押しで連打！ 最後は大もちラッシュ（点数2ばい）！", "center", intro);
    label(fontW, 26, W / 2, 432, "ステージ：" + theme.name + "　　曲：" + song.name, "center", intro);
    const countLabel = label(fontY, 80, 1190, 600, "", "center", intro);
    // れんしゅう: 説明のあいだに、点数の入らない印を流す
    const PR_Y = 640;
    const practice = [{
      t: 1.9,
      k: "T",
      done: false
    }, {
      t: 2.5,
      k: "T",
      done: false
    }, {
      t: 3.1,
      k: "h",
      done: false
    }, {
      t: 3.7,
      k: "T",
      done: false
    }, {
      t: 4.3,
      k: "T",
      done: false
    }];
    const introT = () => INTRO_SEC - introLeft;
    label(fontY, 26, W / 2, 526, "▼ れんしゅう（点数は入りません）タップしてみよう！", "center", intro);
    const pv = new View({
      scene,
      width: W,
      height: H
    });
    pv.draw = r => {
      r.save();
      r.opacity(0.85);
      r.fillRect(110, PR_Y - 48, 980, 96, "#3a1e2a");
      r.restore();
      r.fillRect(110, PR_Y - 48, 980, 4, "#ffd040");
      r.fillRect(110, PR_Y + 44, 980, 4, "#ffd040");
      const jd = img("judge");
      drawImg(r, "judge", JUDGE_X - jd.width / 2, PR_Y - jd.height / 2);
      const pt = introT();
      for (let i = practice.length - 1; i >= 0; i--) {
        const e = practice[i];
        const d = e.t - pt;
        if (d > LEAD || d < -0.3 || e.k === "T" && e.done) continue;
        const x = JUDGE_X + d / LEAD * (1090 - JUDGE_X);
        if (x > 1090) continue;
        const id = e.k === "T" ? "note_tsuki" : "note_te";
        const s2 = e.k === "T" ? 0.9 : 0.72;
        const a = img(id);
        drawImg(r, id, x - a.width * s2 / 2, PR_Y - a.height * s2 / 2, s2, s2, d < 0 ? Math.max(0, 1 + d * 3) : 1);
      }
    };
    pv.onUpdate.add(() => pv.modified());
    intro.append(pv);
    const practiceTap = () => {
      const pt = introT();
      let best = null;
      let bd = 9;
      practice.forEach(e => {
        if (e.done) return;
        const d = Math.abs(e.t - pt);
        if (d < bd) {
          bd = d;
          best = e;
        }
      });
      if (!best || bd > F_W) return;
      const e = best;
      e.done = true;
      if (e.k === "h") {
        se("ouch", 0.5);
        popText("いたっ！ 手のときは押さない！", fontR, 40, W / 2, PR_Y - 120, 0.9);
        return;
      }
      const k = bd <= S_W ? "S" : bd <= A_W ? "A" : bd <= B_W ? "B" : "F";
      se(k === "F" ? "miss" : "pettan", 0.5);
      if (k === "S") se("perfect", 0.3);
      popText(k, rankFonts[k], 64, JUDGE_X, PR_Y + 10, 0.4);
    };
    // ======== エフェクト ========
    const burst = (x, y, n, sp, cols) => {
      for (let k = 0; k < n; k++) {
        const a = rand() * Math.PI * 2,
          v = sp * (0.4 + rand() * 0.8);
        parts.push({
          x,
          y,
          vx: Math.cos(a) * v,
          vy: Math.sin(a) * v - 200,
          g: 900,
          life: 0.6,
          max: 0.6,
          size: 8 + rand() * 8,
          col: cols[Math.floor(rand() * cols.length)],
          img: "",
          spin: 0
        });
      }
    };
    const sparkle = (x, y, n) => {
      for (let k = 0; k < n; k++) {
        const a = k / n * Math.PI * 2;
        const vx = Math.cos(a) * 500,
          vy = Math.sin(a) * 500;
        parts.push({
          x,
          y,
          vx,
          vy,
          g: 0,
          life: 0.3,
          max: 0.3,
          size: 30,
          col: "",
          img: "spark",
          spin: 0
        });
      }
    };
    const confetti = n => {
      for (let k = 0; k < n; k++) {
        parts.push({
          x: rand() * W,
          y: 300 + rand() * 60,
          vx: (rand() - 0.5) * 300,
          vy: -300 - rand() * 300,
          g: 600,
          life: 1.4,
          max: 1.4,
          size: 8 + rand() * 6,
          col: "hsl(" + Math.floor(rand() * 360) + ",95%,65%)",
          img: "",
          spin: 0
        });
      }
    };
    // 舞台の中の位置を、画面の位置にする
    // (カメラがアップや俯瞰のときも、文字がもちのまわりに出るようにする)
    const sx = x => {
      if (shot === 2) return x;
      const b = W / 2 * (1 - STAGE_S) + x * STAGE_S;
      return shot === 1 ? W / 2 + (b - W / 2) * UP_ZOOM : b;
    };
    const sy = y => {
      if (shot === 2) return y - 20;
      const b = H * (1 - STAGE_S) + y * STAGE_S;
      return shot === 1 ? Math.max(260, 450 + (b - (H * (1 - STAGE_S) + 500 * STAGE_S)) * UP_ZOOM) : b;
    };
    const comboMul = () => 1 + Math.min(50, combo) / 25;
    // ======== おもち完成 ========
    const completeMochi = () => {
      glowT = 1.8;
      const ratio = perfectsInMochi / PER_MOCHI;
      const type = ratio >= 0.9 ? 0 : ratio >= 0.75 ? 1 : ratio >= 0.55 ? 2 : ratio >= 0.35 ? 3 : 4;
      made.push(type);
      const bonus = MOCHI_PT + perfectsInMochi * 50;
      score += bonus;
      hits = 0;
      perfectsInMochi = 0;
      se("complete", 0.6);
      se("cheer", 0.5);
      flash = 0.35;
      flashCol = "#fff8e0";
      cheer = 1;
      confetti(40);
      sparkle(MOCHI_X, MOCHI_Y - 80, 12);
      popText(MOCHI_NAMES[type] + " かんせい！", fontY, 60, MOCHI_X, 300, 1.3);
      popText("+" + bonus, fontW, 44, MOCHI_X, 370, 1.3);
    };
    // 判定の文字(判定の輪の下に大きく出す)
    const rankFonts = {
      S: font("#ffe040", "#ff4a8a", 10),
      A: font("#ff8ad8", "#3a1e2a"),
      B: font("#70c8ff", "#3a1e2a"),
      F: font("#a8a0b0", "#3a1e2a")
    };
    let rankLabel = null;
    const RANK_COLS = {
      S: ["#ffe040", "#fff6a0", "#ffb020", "#ffffff"],
      A: ["#ff8ad8", "#ffd0f0", "#ffffff"],
      B: ["#70c8ff", "#c8ecff"],
      F: ["#8a8098", "#b0a8b8"]
    };
    const rankFx = k => {
      const cols = RANK_COLS[k];
      const n = k === "S" ? 10 : k === "A" ? 7 : k === "B" ? 4 : 0;
      for (let i = 0; i < n; i++) {
        const a = rand() * Math.PI * 2,
          v = (k === "S" ? 340 : 260) * (0.5 + rand() * 0.7);
        const bx = Math.cos(a) * v,
          by = Math.sin(a) * v;
        const col = cols[i % cols.length];
        fxs.push({
          kind: "bit",
          x: JUDGE_X,
          y: LANE_Y,
          vx: bx,
          vy: by,
          life: 0.22,
          max: 0.22,
          size: 5 + rand() * 5,
          col
        });
      }
      if (k === "S") {
        fxs.push({
          kind: "rays",
          x: JUDGE_X,
          y: LANE_Y,
          vx: 0,
          vy: 0,
          life: 0.18,
          max: 0.18,
          size: 220,
          col: ""
        });
        fxs.push({
          kind: "ring",
          x: JUDGE_X,
          y: LANE_Y,
          vx: 0,
          vy: 0,
          life: 0.18,
          max: 0.18,
          size: 190,
          col: ""
        });
        punch = 0.5;
        sStreak++;
        if (sStreak % 5 === 0) {
          popText("S×" + sStreak + " れんぞく！", rankFonts.S, 44, JUDGE_X + 290, LANE_Y + 74, 0.8);
          se("perfect", 0.5);
        }
      } else if (k === "A") {
        fxs.push({
          kind: "ring",
          x: JUDGE_X,
          y: LANE_Y,
          vx: 0,
          vy: 0,
          life: 0.16,
          max: 0.16,
          size: 160,
          col: ""
        });
        punch = 0.2;
        sStreak = 0;
      } else if (k === "B") {
        fxs.push({
          kind: "ring",
          x: JUDGE_X,
          y: LANE_Y,
          vx: 0,
          vy: 0,
          life: 0.14,
          max: 0.14,
          size: 130,
          col: ""
        });
        sStreak = 0;
      } else {
        // F: 灰色のけむりがもくもく、判定の輪がぶるっ
        for (let i = 0; i < 3; i++) {
          fxs.push({
            kind: "smoke",
            x: JUDGE_X + (rand() - 0.5) * 60,
            y: LANE_Y + (rand() - 0.5) * 40,
            vx: (rand() - 0.5) * 80,
            vy: -40 - rand() * 60,
            life: 0.3,
            max: 0.3,
            size: 36 + rand() * 20,
            col: cols[i % 2]
          });
        }
        judgeShake = 0.2;
        sStreak = 0;
      }
    };
    const showRank = k => {
      if (rankLabel) {
        const old = rankLabel;
        pops.forEach(pp => {
          if (pp.l === old) pp.life = Math.min(pp.life, 0.01);
        });
      }
      rankFx(k);
      const sz = k === "S" ? 74 : k === "F" ? 56 : 64;
      rankLabel = label(rankFonts[k], sz, JUDGE_X, LANE_Y + 54, k, "center");
      rankLabel.anchorX = 0.5;
      rankLabel.anchorY = 0.5;
      rankLabel.x = JUDGE_X;
      rankLabel.y = LANE_Y + 54 + sz / 2;
      pops.push({
        l: rankLabel,
        life: 0.32,
        vy: k === "F" ? 40 : -20,
        scale: k === "S" ? 1.5 : 1.2
      });
    };
    // ======== 判定 ========
    const breakCombo = () => {
      if (combo >= 10) popText("コンボがとぎれた…", fontR, 32, W / 2, 250);
      combo = 0;
    };
    // 連打で1回つく
    const rendaPound = e => {
      lastHit = now;
      se("pettan", 0.5);
      squash = 0.8;
      const pts = Math.round(RENDA_PT * comboMul() * (e.rush ? 2 : 1));
      score += pts;
      rendaPts += pts;
      rendaCount++;
      hits++;
      perfectsInMochi++;
      shake = 0.08;
      const mx = MOCHI_X,
        my = MOCHI_Y - 90;
      burst(mx, my, 5, 380, ["#ffffff", "#fff4d0", "#ffe060"]);
      if (rendaCount % 4 === 0) popText(rendaCount + "回！", fontY, 44, sx(mx + 170), sy(my - 120), 0.4);
      if (hits >= PER_MOCHI) completeMochi();
    };
    scene.onPointUpCapture.add(() => {
      held = false;
      heldFromRenda = false;
    });
    scene.onPointDownCapture.add(() => {
      if (phase === "intro") {
        practiceTap();
        return;
      }
      if (phase !== "play") return;
      held = true;
      const rd = rendaNow();
      if (rd) {
        // 連打パートでは、押すたびにつく(押しっぱなしでも自動でつく)
        heldFromRenda = true;
        rendaTimer = RENDA_SEC;
        rendaPound(rd);
        return;
      }
      lastHit = now;
      // いちばん近い「つく」印
      let best = null;
      let bd = 9;
      for (let i = 0; i < evs.length; i++) {
        const e = evs[i];
        if (e.done || e.kind !== "T") continue;
        const d = Math.abs(e.t - now);
        if (d < bd) {
          bd = d;
          best = e;
        }
        if (e.t > now + 1) break;
      }
      const hn = handNear();
      if (hn >= 0 && !(best && bd <= F_W && bd < hn)) {
        // たぬきの手をついてしまった
        ouchT = 0.5;
        shake = 0.35;
        se("ouch", 0.7);
        score = Math.max(0, score - OUCH_PT);
        breakCombo();
        popText("いたーっ！ -" + OUCH_PT, fontR, 56, sx(860), sy(330), 0.9);
        return;
      }
      se("pettan", 0.7);
      squash = 1;
      const mx = MOCHI_X,
        my = MOCHI_Y - 90;
      parts.push({
        x: mx,
        y: my,
        vx: 0,
        vy: 0,
        g: 0,
        life: 0.25,
        max: 0.25,
        size: 260,
        col: "",
        img: "splash",
        spin: 0
      });
      if (best && bd <= B_W) {
        best.done = true;
        const rank = bd <= S_W ? "S" : bd <= A_W ? "A" : "B";
        best.res = rank;
        ranks[rank]++;
        showRank(rank);
        combo++;
        maxCombo = Math.max(maxCombo, combo);
        const pts = Math.round((rank === "S" ? S_PT : rank === "A" ? A_PT : B_PT) * comboMul() * (best.rush ? 2 : 1));
        score += pts;
        hits++;
        perfectsInMochi += rank === "S" ? 1 : rank === "A" ? 0.5 : 0;
        shake = rank === "S" ? 0.18 : 0.1;
        if (rank === "S") {
          se("perfect", 0.35);
          sparkle(mx, my, 6);
          burst(mx, my, 6, 420, ["#ffe040", "#fff6a0", "#ffb020"]);
          cheer = Math.min(1, cheer + 0.15);
          popText(combo % 8 === 0 ? "よいしょー！" : "ペッタン！", fontY, 52, sx(mx - 170), sy(my - 110), 0.6);
        } else if (rank === "A") {
          se("good", 0.4);
          sparkle(mx, my, 5);
          popText("ペッタン", fontW, 46, sx(mx - 170), sy(my - 110), 0.5);
        } else {
          se("good", 0.3);
          popText("ペタッ", fontC, 40, sx(mx - 170), sy(my - 110), 0.5);
        }
        burst(mx, my, rank === "S" ? 14 : 8, 420, ["#ffffff", "#fff4d0", "#ffe0f0"]);
        popText("+" + pts, fontW, 34, sx(mx + 150), sy(my - 60), 0.5);
        if (combo > 0 && combo % 10 === 0) {
          se("cheer", 0.45);
          cheer = 1;
          confetti(20);
          popText(combo + "コンボ！", fontP, 64, W / 2, 250, 1.0);
        }
        if (hits >= PER_MOCHI) completeMochi();
      } else if (best && bd <= F_W) {
        // 完全にずれた: F(ミス)
        best.done = true;
        best.res = "F";
        ranks.F++;
        showRank("F");
        se("miss", 0.45);
        breakCombo();
        popText("ベチャッ…", fontC, 40, sx(mx - 170), sy(my - 110), 0.5);
      } else {
        // 何もないところでついた
        breakCombo();
        popText("スカッ", fontC, 40, sx(mx - 170), sy(my - 110), 0.5);
      }
    });
    // ======== おしまい: 称号・点数・判定のメダルを、順番にポンッと出す ========
    let finished = false;
    const endItems = [];
    let endT = 0;
    let happy = false;
    const chars = [];
    const pop = (e, at, s = 1) => {
      e.scaleX = e.scaleY = 0;
      e.modified();
      endItems.push({
        e,
        at,
        s,
        done: false
      });
    };
    const centered = l => {
      l.anchorX = 0.5;
      l.anchorY = 0.5;
      l.x += 620;
      l.y += l.fontSize / 2;
      return l;
    };
    const finish = () => {
      if (finished) return;
      finished = true;
      phase = "end";
      g.game.vars.gameState.score = score;
      se("finish", 0.7);
      const over = new g.FilledRect({
        scene,
        cssColor: "rgba(40,16,30,0.72)",
        width: W,
        height: H
      });
      scene.append(over);
      // 紙ふぶきは、暗くした幕の上にも出す
      const fx = new View({
        scene,
        width: W,
        height: H
      });
      fx.draw = r => drawParts(r);
      fx.onUpdate.add(() => fx.modified());
      scene.append(fx);
      pop(centered(label(fontY, 56, W / 2, 6, "おしまい！", "center")), 0);
      // 称号
      let ti = TITLES.length - 1;
      for (let i = 0; i < TITLES.length; i++) {
        if (score >= TITLES[i][0]) {
          ti = i;
          break;
        }
      }
      const rb = new g.Sprite({
        scene,
        src: img("title_ribbon"),
        x: W / 2,
        y: 172,
        anchorX: 0.5,
        anchorY: 0.5
      });
      scene.append(rb);
      pop(rb, 1.15, 0.9);
      const tf = ti <= 2 ? font("#fff27a", "#3a1e2a", 10) : font("#ffffff", "#3a1e2a", 8);
      pop(centered(label(fontC, 24, W / 2, 74, "あなたの称号は…", "center")), 1.05);
      pop(centered(label(tf, ti <= 2 ? 56 : 50, W / 2, ti <= 2 ? 140 : 143, TITLES[ti][1], "center")), 1.2);
      // 点数
      pop(centered(label(fontW, 60, W / 2, 238, score + "てん", "center")), 0.15);
      // 判定のメダル
      const RK = [["S", "medal_s", "かんぺき", "#ffe040"], ["A", "medal_a", "おしい", "#ff8ad8"], ["B", "medal_b", "ずれた", "#70c8ff"], ["F", "medal_f", "ミス", "#b8b0c0"]];
      RK.forEach((q, i) => {
        const cx = 295 + i * 230;
        const m = new g.Sprite({
          scene,
          src: img(q[1]),
          x: cx,
          y: 400,
          anchorX: 0.5,
          anchorY: 0.5
        });
        scene.append(m);
        pop(m, 0.3 + i * 0.12, q[0] === "S" ? 0.82 : 0.72);
        const cf = font(q[3], "#3a1e2a", 8);
        const n = ranks[q[0]];
        pop(centered(label(cf, q[0] === "S" ? 58 : 50, cx, 492, n + "回", "center")), 0.35 + i * 0.12);
        pop(centered(label(fontW, 24, cx, 552, q[2], "center")), 0.35 + i * 0.12);
      });
      // 完成したおもち
      const n = Math.min(10, made.length);
      made.slice(0, 10).forEach((m, i) => {
        const mx = W / 2 - (n - 1) * 40 + i * 80;
        const sp = new g.Sprite({
          scene,
          src: img(MOCHI_TYPES[m]),
          x: mx,
          y: 604,
          anchorX: 0.5,
          anchorY: 0.5
        });
        scene.append(sp);
        pop(sp, 0.8 + i * 0.03, 0.62);
      });
      pop(centered(label(fontY, 26, W / 2, 640, "完成したおもち " + made.length + "こ　　さいだい " + maxCombo + "コンボ", "center")), 0.85);
      pop(centered(label(fontW, 22, W / 2, 680, "舞台：" + theme.name + " × 曲：" + song.name, "center")), 0.9);
      // うさぎとたぬきが正面を向いて、喜ぶ(またはしょんぼり)
      happy = score >= 18000;
      const mood = happy ? "joy" : "sad";
      [["usagi_" + mood, 112], ["tanuki_" + mood, 1168]].forEach(q => {
        const ch = new g.Sprite({
          scene,
          src: img(q[0]),
          x: q[1],
          y: 430,
          anchorX: 0.5,
          anchorY: 0.5
        });
        scene.append(ch);
        pop(ch, 1.3, 0.72);
        chars.push(ch);
      });
    };
    const updateEnd = () => {
      endT += dt;
      if (endT > 1.6) {
        // 喜んでいたらぴょんぴょん、しょんぼりならゆらゆら
        chars.forEach((c, i) => {
          c.y = 430 + (happy ? -Math.abs(Math.sin(endT * 7 + i)) * 26 : Math.sin(endT * 2 + i) * 4);
          c.modified();
        });
      }
      endItems.forEach(it => {
        const t = (endT - it.at) / 0.25;
        if (t <= 0 || it.done) return;
        // ちょっと大きくなってから元の大きさに(ポンッ)
        const k = t >= 1 ? 1 : 1 + 2.7 * Math.pow(t - 1, 3) + 1.7 * Math.pow(t - 1, 2);
        it.e.scaleX = it.e.scaleY = it.s * k;
        it.e.modified();
        if (t >= 1) {
          it.done = true;
          if (it.at >= 1.2) {
            // 称号が出たら、歓声と紙ふぶき
            se("complete", 0.6);
            se("cheer", 0.6);
            confetti(50);
            sparkle(W / 2, 170, 14);
          }
        }
      });
    };
    // ======== 毎フレーム ========
    let lastCount = -1;
    let curSection = 0;
    scene.onUpdate.add(() => {
      if (phase === "intro") {
        introLeft -= dt;
        const n = Math.ceil(introLeft);
        if (n !== lastCount && n <= 3 && n > 0) {
          se("count", 0.5);
          lastCount = n;
        }
        setText(countLabel, n <= 3 && n > 0 ? String(n) : "");
        if (introLeft <= 0) {
          phase = "play";
          intro.destroy();
          se("go", 0.6);
          popText("ペッタン、スタート！", fontY, 80, W / 2, 300, 1.0);
        }
      } else if (phase === "play") {
        now += dt;
        if (now >= playSec) finish();
      }
      if (phase === "play") {
        // 曲: 8分音符ごとに太鼓・かね・琴
        while (slotIdx < slots.length && slots[slotIdx].t <= now) {
          const s = slots[slotIdx];
          const dr = song.drum.charAt(s.idx % 8);
          if (dr === "D" || dr === "d") se("don", dr === "D" ? 0.55 : 0.38);else if (dr === "k") se("ka", 0.3);
          if (s.beat) lastBeat = s.t;
          const m = song.mel[s.idx % song.mel.length];
          const ins = song.inst.charAt(Math.floor(s.idx / 8) % song.inst.length);
          if (m >= 0) se(ins + m, (s.rush ? 0.42 : 0.32) * (ins === "f" ? 1.1 : 1));
          slotIdx++;
        }
        // 合図: おもちの印が輪にかさなる1拍前に「カッ」
        for (let i = 0; i < evs.length; i++) {
          const e = evs[i];
          if (e.t > now + 1.5) break;
          if (e.kind === "T" && !e.cued && now >= e.t - slotLen() * 2) {
            e.cued = true;
            se("cue", 0.3);
          }
        }
        // ラスト10秒: 太鼓のロールと、画面のふちが赤く点めつ
        if (!lastTen && now >= playSec - 10) {
          lastTen = true;
          rollT = 0.7;
          popText("あと10秒！", fontR, 80, W / 2, 300, 1.3);
        }
        if (rollT > 0) {
          rollT -= dt;
          rollTick -= dt;
          if (rollTick <= 0) {
            se("don", 0.45);
            rollTick = 0.06;
          }
        }
        // 連打パート
        const rd = rendaNow();
        if (rd && held && now >= rd.t) {
          rendaTimer -= dt;
          if (rendaTimer <= 0) {
            rendaPound(rd);
            rendaTimer = RENDA_SEC;
          }
        }
        for (let i = 0; i < evs.length; i++) {
          const e = evs[i];
          if (e.t > now + 1.2) break;
          if (e.kind !== "R") continue;
          if (e.res === "" && e.t - now < 0.9) {
            e.res = "warned";
            popText("長押しで連打！", fontY, 64, W / 2, 330, 1.0);
          }
          if (!e.done && now > e.t2) {
            e.done = true;
            if (rendaCount > 0) {
              se("good", 0.5);
              popText("連打 " + rendaCount + "回！ +" + rendaPts, fontP, 50, W / 2, 330, 1.0);
            }
            rendaCount = 0;
            rendaPts = 0;
          }
        }
        // 連打のあとも押しっぱなしで、たぬきの手が来たら手をつく
        if (held && heldFromRenda && !rendaNow() && handIn()) {
          heldFromRenda = false;
          ouchT = 0.5;
          shake = 0.35;
          se("ouch", 0.7);
          score = Math.max(0, score - OUCH_PT);
          breakCombo();
          popText("はなすのがおそい！ -" + OUCH_PT, fontR, 50, sx(860), sy(330), 0.9);
        }
        // たぬきの「はいっ」と、のがした「つく」
        for (let i = 0; i < evs.length; i++) {
          const e = evs[i];
          if (e.t > now + 1) break;
          if (e.done) continue;
          if (e.kind === "h" && now >= e.t) {
            e.done = true;
            se("hai", 0.35);
          } else if (e.kind === "T" && now > e.t + F_W) {
            e.done = true;
            e.res = "F";
            ranks.F++;
            showRank("F");
            se("miss", 0.35);
            breakCombo();
            popText("ミス", fontR, 40, sx(MOCHI_X - 170), sy(MOCHI_Y - 200), 0.5);
          }
        }
        // 区間がかわる
        const si = SECTIONS.indexOf(sectionAt(now));
        if (si !== curSection) {
          curSection = si;
          sectionName = SECTIONS[si].name;
          if (SECTIONS[si].rush) {
            se("rush", 0.6);
            flash = 0.4;
            flashCol = "#ffe060";
            confetti(30);
          } else se("hai", 0.5);
          popText(sectionName, SECTIONS[si].rush ? fontP : fontC, SECTIONS[si].rush ? 60 : 52, W / 2, 250, 1.6);
        }
      }
      if (ouchT > 0) ouchT -= dt;
      if (glowT > 0) glowT -= dt;
      if (phase === "end") updateEnd();
      if (phase === "play") {
        // 10秒ごとにカメラを切りかえる(いつもの→アップ→俯瞰)
        const ns = Math.floor(now / SHOT_SEC) % 3;
        if (ns !== shot) {
          shot = ns;
          flash = Math.max(flash, 0.3);
          flashCol = "#ffffff";
        }
        // 時間帯がかわったら知らせる
        const ti = todNow().i;
        if (ti !== todIdx) {
          todIdx = ti;
          popText(["", "お昼になったよ！", "夕方になったよ！", "夜になったよ！"][ti], fontW, 44, W / 2, 330, 1.4);
        }
      } else if (phase === "end") {
        shot = 0;
      }
      if (squash > 0) squash = Math.max(-0.3, squash - dt * 9);else if (squash < 0) squash = Math.min(0, squash + dt * 3);
      if (shake > 0) shake = Math.max(0, shake - dt);
      if (flash > 0) flash = Math.max(0, flash - dt * 2);
      cheer = Math.max(0, cheer - dt * 0.5);
      crowdT += dt * (1.5 + Math.min(1, combo / 30) * 3 + cheer * 4);
      for (let i = fxs.length - 1; i >= 0; i--) {
        const f = fxs[i];
        f.x += f.vx * dt;
        f.y += f.vy * dt;
        f.vx *= 0.92;
        f.vy *= 0.92;
        f.life -= dt;
        if (f.life <= 0) fxs.splice(i, 1);
      }
      if (punch > 0) punch = Math.max(0, punch - dt * 7);
      if (judgeShake > 0) judgeShake = Math.max(0, judgeShake - dt);
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i];
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.vy += p.g * dt;
        p.vx *= 0.96;
        p.vy *= 0.96;
        p.spin += dt * 4;
        p.life -= dt;
        if (p.life <= 0) parts.splice(i, 1);
      }
      for (let i = pops.length - 1; i >= 0; i--) {
        const pp = pops[i];
        pp.life -= dt;
        pp.l.y += pp.vy * dt;
        pp.scale += (1 - pp.scale) * Math.min(1, dt * 14);
        pp.l.scaleX = pp.l.scaleY = pp.scale;
        pp.l.opacity = Math.min(1, pp.life * 3);
        pp.l.modified();
        if (pp.life <= 0) {
          pp.l.destroy();
          pops.splice(i, 1);
        }
      }
      if (phase !== "end") g.game.vars.gameState.score = score;
      setText(scoreLabel, score + "てん");
      setText(timeLabel, "のこり " + Math.max(0, Math.ceil(playSec - now)));
      setText(comboLabel, combo >= 2 ? combo + "コンボ ×" + comboMul().toFixed(1) : "");
      setText(mochiLabel, "おもち " + made.length + "こ");
      setText(todLabel, "じかん：" + TIMES[todNow().i].name);
      view.modified();
    });
  });
  g.game.pushScene(scene);
}
return module.exports;
},
},"parameterObject": {type:"script",path:"script/parameterObject.js",global:true,execute: rv => {
'use strict';
const module = rv.module;const exports = module.exports;const require = module.require;const __dirname = rv.dirname;const __filename = rv.filename;
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
return module.exports;
},
},}}