module.exports={assets:{"_bootstrap": {type:"script",path:"script/_bootstrap.js",global:true,execute: rv => {
'use strict';
const module = rv.module;const exports = module.exports;const require = module.require;const __dirname = rv.dirname;const __filename = rv.filename;
"use strict";

// 通常このファイルを編集する必要はありません。ゲームの処理は main.js に記述してください
const main_1 = require("./main");
module.exports = originalParam => {
  const param = {};
  Object.keys(originalParam).forEach(key => {
    param[key] = originalParam[key];
  });
  // セッションパラメーター
  param.sessionParameter = {};
  // 乱数生成器
  param.random = g.game.random;
  const limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数
  const scene = new g.Scene({
    game: g.game,
    name: "_bootstrap"
  });
  // セッションパラメーターを受け取ってゲームを開始します
  scene.onMessage.add(msg => {
    if (msg.data && msg.data.type === "start" && msg.data.parameters) {
      param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加
      if (msg.data.parameters.randomSeed != null) {
        param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
      }
      g.game.popScene();
      (0, main_1.main)(param);
    }
  });
  scene.onLoad.add(() => {
    let currentTickCount = 0;
    scene.onUpdate.add(function () {
      currentTickCount++;
      // 待ち時間を超えた場合はゲームを開始します
      if (currentTickCount > limitTickToWait) {
        g.game.popScene();
        (0, main_1.main)(param);
      }
    });
  });
  g.game.pushScene(scene);
};
return module.exports;
},
},"main": {type:"script",path:"script/main.js",global:true,execute: rv => {
'use strict';
const module = rv.module;const exports = module.exports;const require = module.require;const __dirname = rv.dirname;const __filename = rv.filename;
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.main = main;
// ======== 調整用パラメータ ========
const W = 1280;
const H = 720;
const K = 1280; // 遠近の強さ(手前で 1u = 320px)
const D = 4; // カメラから自分までの距離(u)
const CAM_H = 1.7; // カメラの高さ(u)。板より少し低く、上から見下ろす
const FOOT_Y = 690; // 自分の足もとの高さ(画面)
const HOR = FOOT_Y - CAM_H * K / D; // 地平線の高さ
const UNIT = 320; // 絵の 320px = 1u
const ROAD = 1.2; // 道の半分の幅(u)
const MOVE = 0.8; // 自分が動ける範囲(u)
const Z_FAR = 40; // 板が出てくる遠さ(u)
const DRAG_RATE = 1 / 330; // 指を1px動かしたときの横移動(u)
const TAP_MOVE = 16; // これより動かなければタップ(px)
const TAP_SEC = 0.35;
const JUMP_V = 3.4; // ジャンプの初速(u/秒)
const GRAVITY = 9.4;
const TOL = 0.11; // 型からずれてもよい幅(u)
const PERFECT = 0.04; // ピッタリの幅(u)
const LOW_MAX = 0.15; // ふつうの型: この高さより上だと頭をぶつける
const HIGH_MIN = 0.28; // 高い型: この高さより上でないと首をぶつける
const BOARD_TOP = 1.175; // 頭の高さにある板の上のはしの高さ(u)
const HIGH_LIFT = 0.45; // 高い型の板は、これだけ上にある(u)
const SPEED0 = 11; // 走る速さ(u/秒)
const SPEED1 = 20;
const GAP_SEC0 = 1.5; // 板と板の間(秒)。速くなっても、次の板まで同じくらいの時間がある
const GAP_SEC1 = 1.25;
const PASS_PT = 100;
const PERFECT_PT = 100;
const COMBO_PT = 15; // 1れんぞくごとの上乗せ
const COMBO_MAX_PT = 300;
const TRAP_RATE = 0.16; // 板を出すとき、石かねこも置く確率
const TRAP_HIT = 0.26; // 石・ねこにつまずく横の近さ(u)
const FALL_SEC = 1.4; // ころんで止まっている秒
const INTRO_SEC = 5;
const END_SEC = 3;
const STAGES = [{
  name: "ひるの住宅街",
  bg: "bg_day",
  top: "#3878e8",
  road: ["#a8a098", "#9c948c"],
  side: ["#68b850", "#5aa844"],
  edge: "#f8f8f0",
  props: ["pole", "house", "tree", "wall", "wall"]
}, {
  name: "夕やけの河原",
  bg: "bg_river",
  top: "#583890",
  road: ["#c8a070", "#bc9464"],
  side: ["#7aa848", "#6c983e"],
  edge: "#f8e8c8",
  props: ["susuki", "susuki", "sign", "tree", "pole"]
}, {
  name: "よるの商店街",
  bg: "bg_night",
  top: "#101838",
  road: ["#686078", "#605870"],
  side: ["#8a8098", "#7e748c"],
  edge: "#f8e070",
  props: ["shop", "lantern", "vending", "shop", "lantern"]
}];
// 板の絵の真ん中から見た、ほんとうの型(角刈り)の位置(u)
const HOLE_OFF = {
  ground: 0,
  high: 0,
  kid_r: -0.4,
  kid_l: 0.4
};
class View extends g.E {
  constructor() {
    super(...arguments);
    this.draw = () => undefined;
  }
  renderSelf(r) {
    this.draw(r);
    return true;
  }
}
function main(param) {
  const imageIds = ["bg_day", "bg_river", "bg_night", "man_run0", "man_run1", "man_jump", "man_stand", "man_fall", "rock", "cat", "panel_ground", "panel_high", "panel_kid_l", "panel_kid_r", "piece", "shadow", "spark", "star", "pole", "wall", "house", "tree", "susuki", "sign", "lantern", "vending", "shop", "logo"];
  const audioIds = ["jump", "pass", "perfect", "crash", "miss", "fall", "beep", "go", "finish", "combo", "land"];
  const scene = new g.Scene({
    game: g.game,
    assetIds: imageIds.concat(audioIds.map(a => "se_" + a), ["bgm"])
  });
  let time = 70;
  if (param.sessionParameter.totalTimeLimit) {
    time = param.sessionParameter.totalTimeLimit;
  }
  // ランキングモードでは g.game.vars.gameState.score をスコアとして扱う
  g.game.vars.gameState = {
    score: 0
  };
  scene.onLoad.add(() => {
    const dt = 1 / g.game.fps;
    const rand = () => param.random.generate();
    const se = (id, vol = 0.8) => {
      scene.asset.getAudioById("se_" + id).play().changeVolume(vol);
    };
    const img = id => scene.asset.getImageById(id);
    const surf = {};
    imageIds.forEach(id => {
      surf[id] = g.SurfaceUtil.asSurface(img(id));
    });
    // ======== 状態 ========
    const playSec = Math.max(20, time - INTRO_SEC - END_SEC);
    let phase = "intro";
    let elapsed = 0; // 走りはじめてからの秒
    let introLeft = INTRO_SEC;
    let dist = 0; // 走った距離(u)
    let speed = 0;
    let px = 0; // 自分の横の位置(u)
    let py = 0; // ジャンプの高さ(u)
    let vy = 0;
    let stun = 0; // ぶつかってふらふらしている秒
    let fall = 0; // ころんで止まっている秒
    let score = 0;
    let combo = 0;
    let nextGap = 6; // 次の板までの距離
    let panelCount = 0;
    let stage = 0;
    let stageFade = 1;
    let prevStage = 0;
    let shake = 0;
    let runAnim = 0;
    const panels = [];
    const props = [];
    const traps = [];
    const pieces = [];
    let propGap = 0;
    const scale = z => K / (z + D);
    // コースのカーブ(横)と坂(高さ)。走った距離 d だけで決まるので、みんな同じコース
    const ramp = d => Math.min(1, Math.max(0, (d - 25) / 50));
    const courseX = d => ramp(d) * (6 * Math.sin(d / 45) + 1.5 * Math.sin(d / 22 + 1.3));
    const courseY = d => ramp(d) * (4 * Math.sin(d / 45 + 0.5) + 1.2 * Math.sin(d / 22 + 2));
    let baseX = 0;
    let slopeX = 0;
    let baseY = 0;
    // 自分の足もとを基準にした、奥(z)の道の横ずれと高さ
    const curveX = z => courseX(dist + z) - baseX - slopeX * z;
    const elev = z => courseY(dist + z) - baseY;
    const groundY = z => HOR + (CAM_H - elev(z)) * scale(z);
    const camX = () => px * 0.35;
    const screenX = (x, z) => W / 2 + (x - camX() + curveX(z)) * scale(z);
    // ======== 絵を描く ========
    const view = new View({
      scene,
      width: W,
      height: H
    });
    scene.append(view);
    const drawBg = (r, st, alpha) => {
      r.save();
      if (alpha < 1) r.opacity(alpha);
      r.fillRect(0, 0, W, HOR, st.top);
      const a = img(st.bg);
      const off = -camX() * 60 - slopeX * 700;
      let x0 = (off % a.width + a.width) % a.width - a.width;
      while (x0 < W) {
        r.drawImage(surf[st.bg], 0, 0, a.width, a.height, x0, HOR + 8 - a.height);
        x0 += a.width;
      }
      r.restore();
    };
    // 坂の向こうにかくれるところ: 奥の深さ clipZ[i] から先は、画面の y が clipV[i] より下を描かない
    const clipZ = [];
    const clipV = [];
    const clipFor = z => {
      let c = H;
      for (let i = 0; i < clipZ.length && clipZ[i] <= z; i++) c = clipV[i];
      return c;
    };
    const drawGround = (r, st) => {
      r.fillRect(0, HOR, W, H - HOR, st.side[0]);
      // 手前から奥へ、細い帯ごとに描く
      clipZ.length = 0;
      clipV.length = 0;
      let clip = H;
      let z0 = -0.6;
      let y0 = groundY(z0),
        c0 = curveX(z0),
        s0 = scale(z0);
      while (z0 < Z_FAR + 2) {
        const z1 = z0 + 0.15 + Math.max(0, z0) * 0.04;
        const y1 = groundY(z1),
          c1 = curveX(z1),
          s1 = scale(z1);
        clipZ.push(z0);
        clipV.push(clip);
        if (y1 < clip) {
          const band = (Math.floor((z0 + dist) / 1.6) % 2 + 2) % 2;
          const bottom = Math.min(y0, clip);
          for (let y = Math.max(0, Math.floor(y1)); y < bottom; y += 3) {
            const t = y0 === y1 ? 0 : (y0 - y) / (y0 - y1);
            const sc = s0 + (s1 - s0) * t,
              c = c0 + (c1 - c0) * t;
            const hh = Math.min(3, bottom - y);
            r.fillRect(0, y, W, hh, st.side[band]);
            const l = W / 2 + (-ROAD - camX() + c) * sc,
              rr = W / 2 + (ROAD - camX() + c) * sc;
            r.fillRect(l, y, rr - l, hh, st.road[band]);
            const e = Math.max(1, 0.05 * sc);
            r.fillRect(l - e, y, e, hh, st.edge);
            r.fillRect(rr, y, e, hh, st.edge);
          }
          clip = Math.min(clip, y1);
        }
        z0 = z1;
        y0 = y1;
        c0 = c1;
        s0 = s1;
      }
    };
    const drawSprite = (r, id, x, z, alpha) => {
      const a = img(id);
      const sc = scale(z) / UNIT;
      const sx = screenX(x, z);
      if (sx + a.width * sc / 2 < 0 || sx - a.width * sc / 2 > W) return;
      const top = groundY(z) - a.height * sc;
      const visH = Math.min(a.height, (clipFor(z) - top) / sc);
      if (visH <= 1) return;
      r.save();
      if (alpha < 1) r.opacity(alpha);
      r.transform([sc, 0, 0, sc, sx - a.width * sc / 2, top]);
      r.drawImage(surf[id], 0, 0, a.width, visH, 0, 0);
      r.restore();
    };
    const drawPanel = (r, p, alpha) => {
      const id = "panel_" + p.kind;
      const sc = scale(p.z) / UNIT;
      // 板をささえる2本の柱(道の両はし)
      const top = BOARD_TOP + (p.kind === "high" ? HIGH_LIFT : 0);
      const s = scale(p.z),
        gy = groundY(p.z),
        pw = Math.max(2, 0.05 * s);
      const clip = clipFor(p.z);
      if (clip <= gy - top * s) return;
      r.save();
      if (alpha < 1) r.opacity(alpha);
      const poleH = Math.min(top * s, clip - (gy - top * s));
      [-ROAD, ROAD - 0.05].forEach(x => r.fillRect(screenX(x, p.z), gy - top * s, pw, poleH, "#5a4030"));
      r.restore();
      // 板は道の幅だけ見せる。型の位置に合わせて絵を切りだす
      const srcX = Math.round(UNIT * (2 - ROAD - p.x));
      const srcW = UNIT * ROAD * 2;
      const h = img(id).height;
      const visH = Math.min(h, (clip - (gy - h * sc)) / sc);
      if (visH <= 1) return;
      r.save();
      if (alpha < 1) r.opacity(alpha);
      r.transform([sc, 0, 0, sc, screenX(-ROAD, p.z), groundY(p.z) - h * sc]);
      r.drawImage(surf[id], srcX, 0, srcW, visH, 0, 0);
      r.restore();
    };
    const drawMan = r => {
      const sx = screenX(px, 0),
        gy = groundY(0);
      // 影
      const sh = img("shadow"),
        ss = Math.max(0.5, 1 - py * 0.6);
      r.save();
      r.opacity(0.9);
      r.transform([ss, 0, 0, ss, sx - sh.width * ss / 2, gy - sh.height * ss / 2]);
      r.drawImage(surf.shadow, 0, 0, sh.width, sh.height, 0, 0);
      r.restore();
      let id = "man_stand";
      const runId = Math.floor(runAnim) % 2 === 0 ? "man_run0" : "man_run1";
      if (phase === "play" || phase === "end") id = py > 0.02 ? "man_jump" : runId;
      if (stun > 0) id = "man_jump";
      if (fall > 0) id = "man_fall";
      const a = img(id);
      const bob = py <= 0.02 && phase === "play" ? Math.abs(Math.sin(runAnim * Math.PI)) * 8 : 0;
      r.save();
      if (stun > 0 && Math.floor(stun * 12) % 2 === 0) r.opacity(0.5);
      r.drawImage(surf[id], 0, 0, a.width, a.height, sx - a.width / 2, gy - a.height - py * UNIT - bob);
      r.restore();
      if (stun > 0) {
        // 頭のまわりをまわる星
        for (let k = 0; k < 3; k++) {
          const t = stun * 8 + k * 2.1;
          const st = img("star");
          r.drawImage(surf.star, 0, 0, st.width, st.height, sx + Math.cos(t) * 56 - st.width / 2, gy - a.height - py * UNIT - 10 + Math.sin(t) * 16);
        }
      }
    };
    view.draw = r => {
      r.save();
      if (shake > 0) r.translate(Math.sin(shake * 40) * shake * 30, 0);
      if (stageFade < 1) drawBg(r, STAGES[prevStage], 1);
      drawBg(r, STAGES[stage], stageFade);
      drawGround(r, STAGES[stage]);
      const items = [];
      props.forEach(p => {
        items.push({
          z: p.z,
          fn: () => drawSprite(r, p.id, p.x, p.z, p.z < 0 ? Math.max(0, 1 + p.z / 1.5) : 1)
        });
      });
      panels.forEach(p => {
        if (p.broken) return;
        const alpha = p.z < 0 ? Math.max(0, 1 + p.z / 0.6) : Math.min(1, (Z_FAR - p.z) / 4);
        items.push({
          z: p.z,
          fn: () => drawPanel(r, p, alpha)
        });
      });
      traps.forEach(t => {
        if (t.gone) return;
        const alpha = t.z < 0 ? Math.max(0, 1 + t.z / 0.8) : Math.min(1, (Z_FAR - t.z) / 4);
        items.push({
          z: t.z,
          fn: () => drawSprite(r, t.id, t.x, t.z, alpha)
        });
      });
      items.push({
        z: 0.001,
        fn: () => drawMan(r)
      });
      items.sort((a, b) => b.z - a.z);
      items.forEach(it => {
        if (it.z > -D + 0.6) it.fn();
      });
      // ダンボールのかけら
      const pc = img("piece");
      pieces.forEach(q => {
        r.save();
        r.opacity(Math.min(1, q.life * 2));
        r.transform([q.s * Math.cos(q.rot), q.s * Math.sin(q.rot), -q.s * Math.sin(q.rot), q.s * Math.cos(q.rot), q.x, q.y]);
        r.drawImage(surf.piece, 0, 0, pc.width, pc.height, -pc.width / 2, -pc.height / 2);
        r.restore();
      });
      r.restore();
    };
    // ======== 文字 ========
    const font = (color, stroke, sw = 8) => new g.DynamicFont({
      game: g.game,
      fontFamily: "sans-serif",
      fontWeight: "bold",
      size: 64,
      fontColor: color,
      strokeColor: stroke,
      strokeWidth: sw
    });
    const fontW = font("#ffffff", "#201018");
    const fontY = font("#fff040", "#201018");
    const fontR = font("#ff5040", "#ffffff");
    const fontC = font("#60f0ff", "#201018");
    const label = (f, size, x, y, text, align = "left") => {
      const l = new g.Label({
        scene,
        font: f,
        fontSize: size,
        text,
        x,
        y,
        width: 600,
        textAlign: align,
        widthAutoAdjust: false
      });
      if (align === "center") l.x = x - 300;
      if (align === "right") l.x = x - 600;
      scene.append(l);
      return l;
    };
    const setText = (l, t) => {
      if (l.text !== t) {
        l.text = t;
        l.invalidate();
      }
    };
    const scoreLabel = label(fontW, 44, 24, 14, "0てん");
    const timeLabel = label(fontW, 44, W - 24, 14, "", "right");
    const comboLabel = label(fontY, 38, W / 2, 16, "", "center");
    const pops = [];
    const popText = (t, f, size, x, y) => {
      const l = label(f, size, x, y, t, "center");
      pops.push({
        l,
        life: 0.9,
        vy: -60
      });
    };
    // ======== はじめの説明 ========
    const intro = new g.E({
      scene
    });
    scene.append(intro);
    intro.append(new g.FilledRect({
      scene,
      cssColor: "rgba(16,8,24,0.55)",
      width: W,
      height: H
    }));
    const logo = new g.Sprite({
      scene,
      src: img("logo"),
      x: W / 2,
      y: 152,
      anchorX: 0.5,
      anchorY: 0.5,
      scaleX: 0.56,
      scaleY: 0.56
    });
    intro.append(logo);
    const rule = (t, y, f) => {
      const l = new g.Label({
        scene,
        font: f,
        fontSize: 40,
        text: t,
        x: 0,
        y,
        width: W,
        textAlign: "center",
        widthAutoAdjust: false
      });
      intro.append(l);
    };
    rule("指を左右にスライドして、型の位置に合わせよう", 320, fontW);
    rule("高いところの型は、タップでジャンプ！", 380, fontY);
    rule("小さい子どもの型はダミー！自分の型を通れ", 440, fontC);
    rule("ピッタリ通ると高得点！れんぞくでボーナス", 500, fontW);
    const countLabel = new g.Label({
      scene,
      font: fontY,
      fontSize: 90,
      text: "",
      x: 0,
      y: 570,
      width: W,
      textAlign: "center",
      widthAutoAdjust: false
    });
    intro.append(countLabel);
    const stageLabel = label(fontC, 52, W / 2, 84, "", "center");
    let stageLabelLeft = 0;
    // ======== 操作 ========
    let down = null;
    scene.onPointDownCapture.add(ev => {
      down = {
        x: ev.point.x,
        y: ev.point.y,
        t: elapsed,
        moved: 0
      };
    });
    scene.onPointMoveCapture.add(ev => {
      if (!down) return;
      down.moved += Math.abs(ev.prevDelta.x) + Math.abs(ev.prevDelta.y);
      if (phase !== "play" || fall > 0) return;
      px = Math.max(-MOVE, Math.min(MOVE, px + ev.prevDelta.x * DRAG_RATE));
    });
    scene.onPointUpCapture.add(() => {
      if (down && phase === "play" && down.moved < TAP_MOVE && elapsed - down.t < TAP_SEC && py <= 0.001 && stun <= 0 && fall <= 0) {
        vy = JUMP_V;
        py = 0.002;
        se("jump", 0.6);
      }
      down = null;
    });
    // ======== 板・道ばたの物を出す ========
    const progress = () => Math.min(1, elapsed / playSec);
    const spawnPanel = () => {
      const p = progress();
      panelCount++;
      let kind = "ground";
      const r = rand();
      if (panelCount > 2) {
        const high = 0.18 + 0.17 * p,
          kid = p > 0.2 ? 0.16 : 0;
        if (r < high) kind = "high";else if (r < high + kid) kind = rand() < 0.5 ? "kid_l" : "kid_r";
      }
      const lim = kind === "kid_l" || kind === "kid_r" ? 0.4 : 0.75;
      const base = (rand() * 2 - 1) * lim;
      // 後半は型が左右に動く
      const moving = kind === "ground" && p > 0.3 && rand() < 0.25 + 0.25 * p;
      const amp = moving ? Math.min(lim - Math.abs(base), 0.25 + 0.25 * rand()) : 0;
      panels.push({
        z: Z_FAR,
        x: base,
        base,
        kind,
        amp,
        ph: rand() * Math.PI * 2,
        done: false,
        broken: false
      });
    };
    const spawnProp = () => {
      const st = STAGES[stage];
      const id = st.props[Math.floor(rand() * st.props.length)];
      const side = rand() < 0.5 ? -1 : 1;
      const x = id === "wall" ? side * (ROAD + 0.75) : side * (ROAD + 0.6 + rand() * 1.3 + img(id).width / UNIT / 2);
      props.push({
        z: Z_FAR,
        x,
        id
      });
    };
    for (let z = 2; z < Z_FAR; z += 2.2) {
      spawnProp();
      props[props.length - 1].z = z;
    }
    // ======== 石・ねこにつまずいて、前にころぶ ========
    const trip = t => {
      fall = FALL_SEC;
      shake = 0.3;
      se("fall", 0.8);
      const cx = screenX(px, 0),
        cy = groundY(0) - 300;
      popText("ズデーン！", fontR, 64, cx, cy);
      if (t.id === "cat") {
        t.gone = true;
        popText("ニャッ！", fontY, 48, cx + 160, cy + 120);
      }
    };
    // ======== 通れた/ぶつかった ========
    const judge = p => {
      p.done = true;
      const hole = p.x + HOLE_OFF[p.kind];
      const dx = Math.abs(px - hole);
      const heightOk = p.kind === "high" ? py >= HIGH_MIN : py <= LOW_MAX;
      if (dx <= TOL && heightOk && stun <= 0) {
        combo++;
        let pts = PASS_PT + Math.min(COMBO_MAX_PT, (combo - 1) * COMBO_PT);
        const perfect = dx <= PERFECT;
        if (perfect) pts += PERFECT_PT;
        score += pts;
        g.game.vars.gameState.score = score;
        const sy = groundY(0) - 380 - py * UNIT;
        if (perfect) {
          se("perfect", 0.6);
          popText("ピッタリ！ +" + pts, fontY, 52, screenX(px, 0), sy);
          for (let k = 0; k < 8; k++) {
            const a = k / 8 * Math.PI * 2;
            sparks.push({
              x: screenX(px, 0),
              y: sy + 120,
              vx: Math.cos(a) * 320,
              vy: Math.sin(a) * 320,
              life: 0.5
            });
          }
        } else {
          se("pass", 0.7);
          popText("スポッ！ +" + pts, fontW, 44, screenX(px, 0), sy);
        }
        if (combo > 0 && combo % 10 === 0) {
          se("combo", 0.6);
          popText(combo + "れんぞく！", fontC, 60, W / 2, 150);
        }
      } else if (p.kind === "high" && py < HIGH_MIN) {
        // 高い板の下をくぐってしまった: やぶらずに通りすぎるが、れんぞくは失敗
        se("miss", 0.7);
        popText("スカッ…", fontC, 56, screenX(px, 0), groundY(0) - 470);
        if (combo >= 5) popText("れんぞくがとぎれた…", fontR, 36, W / 2, 210);
        combo = 0;
      } else {
        // ダンボールをつきやぶる
        p.broken = true;
        se("crash", 0.8);
        if (combo >= 5) popText("れんぞくがとぎれた…", fontR, 36, W / 2, 210);
        combo = 0;
        stun = 0.7;
        shake = 0.35;
        speed *= 0.55;
        const cx = screenX(px, 0),
          cy = groundY(0) - 200 - py * UNIT;
        popText("バリッ！", fontR, 70, cx, cy - 260);
        for (let k = 0; k < 16; k++) {
          pieces.push({
            x: cx + (rand() - 0.5) * 500,
            y: cy + (rand() - 0.5) * 360,
            vx: (rand() - 0.5) * 900,
            vy: -200 - rand() * 500,
            s: 0.7 + rand() * 0.8,
            rot: rand() * 6,
            life: 0.8 + rand() * 0.4
          });
        }
      }
    };
    const sparks = [];
    const sparkLayer = new View({
      scene,
      width: W,
      height: H
    });
    scene.insertBefore(sparkLayer, scoreLabel);
    sparkLayer.draw = r => {
      const a = img("spark");
      sparks.forEach(s => {
        r.save();
        r.opacity(Math.min(1, s.life * 3));
        r.drawImage(surf.spark, 0, 0, a.width, a.height, s.x - a.width / 2, s.y - a.height / 2);
        r.restore();
      });
    };
    // ======== おしまい ========
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      phase = "end";
      g.game.vars.gameState.score = score;
      se("finish", 0.7);
      const over = new g.FilledRect({
        scene,
        cssColor: "rgba(16,8,24,0.5)",
        width: W,
        height: H
      });
      scene.append(over);
      label(fontY, 96, W / 2, 230, "おしまい！", "center");
      label(fontW, 64, W / 2, 360, score + "てん", "center");
    };
    // ======== 毎フレーム ========
    const bgm = scene.asset.getAudioById("bgm");
    let lastCount = -1;
    scene.onUpdate.add(() => {
      if (phase === "intro") {
        introLeft -= dt;
        const n = Math.ceil(introLeft);
        if (n !== lastCount && n <= 3 && n > 0) {
          se("beep", 0.5);
          lastCount = n;
        }
        countLabel.text = n <= 3 && n > 0 ? String(n) : "";
        countLabel.invalidate();
        if (introLeft <= 0) {
          phase = "play";
          intro.destroy();
          se("go", 0.6);
          popText("スタート！", fontY, 80, W / 2, 260);
          g.game.audio.music.play(bgm);
        }
      } else if (phase === "play") {
        elapsed += dt;
        if (elapsed >= playSec) finish();
      }
      const playing = phase === "play";
      // 速さ
      const target = playing && fall <= 0 ? SPEED0 + (SPEED1 - SPEED0) * progress() : 0;
      speed += (target - speed) * Math.min(1, dt * (fall > 0 ? 6 : stun > 0 ? 0.8 : 2));
      const move = speed * dt;
      dist += move;
      baseX = courseX(dist);
      slopeX = courseX(dist + 0.5) - courseX(dist - 0.5);
      baseY = courseY(dist);
      runAnim += speed * dt * 0.55;
      // ジャンプ
      if (py > 0) {
        py += vy * dt;
        vy -= GRAVITY * dt;
        if (py <= 0) {
          py = 0;
          vy = 0;
          se("land", 0.4);
        }
      }
      if (stun > 0) stun -= dt;
      if (fall > 0) fall -= dt;
      if (shake > 0) shake = Math.max(0, shake - dt);
      // 面がかわる
      const st = Math.min(STAGES.length - 1, Math.floor(progress() * STAGES.length));
      if (st !== stage && playing) {
        prevStage = stage;
        stage = st;
        stageFade = 0;
        setText(stageLabel, STAGES[stage].name);
        stageLabelLeft = 2;
      }
      if (stageFade < 1) stageFade = Math.min(1, stageFade + dt);
      if (stageLabelLeft > 0) {
        stageLabelLeft -= dt;
        stageLabel.opacity = Math.min(1, stageLabelLeft);
        stageLabel.modified();
        if (stageLabelLeft <= 0) setText(stageLabel, "");
      }
      // 板
      if (playing) {
        nextGap -= move;
        if (nextGap <= 0 && elapsed < playSec - 1.5) {
          spawnPanel();
          // ごくまれに、板と板のあいだに石か寝ているねこ
          if (panelCount > 4 && rand() < TRAP_RATE) {
            const gap = SPEED0 + (SPEED1 - SPEED0) * progress();
            const tx = (rand() * 2 - 1) * 0.75;
            traps.push({
              z: Z_FAR + gap * 0.6,
              x: tx,
              id: rand() < 0.5 ? "rock" : "cat",
              done: false,
              gone: false
            });
          }
          const sp = SPEED0 + (SPEED1 - SPEED0) * progress();
          nextGap = sp * (GAP_SEC0 + (GAP_SEC1 - GAP_SEC0) * progress());
        }
      }
      for (let i = panels.length - 1; i >= 0; i--) {
        const p = panels[i];
        p.z -= move;
        if (p.amp > 0) p.x = p.base + Math.sin(p.ph + elapsed * 2.2) * p.amp;
        if (!p.done && p.z <= 0 && playing) judge(p);
        if (p.z < -D + 0.5) panels.splice(i, 1);
      }
      // 石・ねこ
      for (let i = traps.length - 1; i >= 0; i--) {
        const t = traps[i];
        t.z -= move;
        if (!t.done && t.z <= 0) {
          t.done = true;
          if (playing && !t.gone && fall <= 0 && py < 0.2 && Math.abs(px - t.x) < TRAP_HIT) trip(t);
        }
        if (t.z < -D + 0.5) traps.splice(i, 1);
      }
      // 道ばたの物
      propGap -= move;
      if (propGap <= 0) {
        spawnProp();
        propGap = 1.6 + rand() * 1.4;
      }
      for (let i = props.length - 1; i >= 0; i--) {
        props[i].z -= move;
        if (props[i].z < -D + 0.5) props.splice(i, 1);
      }
      // かけら・キラキラ・文字
      for (let i = pieces.length - 1; i >= 0; i--) {
        const q = pieces[i];
        q.x += q.vx * dt;
        q.y += q.vy * dt;
        q.vy += 1400 * dt;
        q.rot += dt * 8;
        q.s += dt * 0.8;
        q.life -= dt;
        if (q.life <= 0) pieces.splice(i, 1);
      }
      for (let i = sparks.length - 1; i >= 0; i--) {
        const s = sparks[i];
        s.x += s.vx * dt;
        s.y += s.vy * dt;
        s.vx *= 0.92;
        s.vy *= 0.92;
        s.life -= dt;
        if (s.life <= 0) sparks.splice(i, 1);
      }
      sparkLayer.modified();
      for (let i = pops.length - 1; i >= 0; i--) {
        const pp = pops[i];
        pp.life -= dt;
        pp.l.y += pp.vy * dt;
        pp.l.opacity = Math.min(1, pp.life * 3);
        pp.l.modified();
        if (pp.life <= 0) {
          pp.l.destroy();
          pops.splice(i, 1);
        }
      }
      // 表示
      setText(scoreLabel, score + "てん");
      const left = Math.max(0, Math.ceil(playSec - elapsed));
      setText(timeLabel, "のこり " + left);
      setText(comboLabel, combo >= 2 ? combo + "れんぞく" : "");
      view.modified();
    });
  });
  g.game.pushScene(scene);
}
return module.exports;
},
},"parameterObject": {type:"script",path:"script/parameterObject.js",global:true,execute: rv => {
'use strict';
const module = rv.module;const exports = module.exports;const require = module.require;const __dirname = rv.dirname;const __filename = rv.filename;
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
return module.exports;
},
},}}